-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 182.75.105.186    Database: nordic-strong
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `login_account_types`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` VALUES (1,'3dfc7420-4562-11ec-81d3-0242ac130003','active',1,'2021-10-17 08:14:33',NULL,'2021-10-17 08:14:33',NULL),
(2,'3dfc74de-4562-11ec-81d3-0242ac130003','inActive',1,'2021-10-17 08:14:33',NULL,'2021-10-17 08:14:33',NULL),
(3,'4abc7420-4562-11ec-81d3-0242ac130003','deleted',1,'2021-10-17 08:14:33',NULL,'2021-10-17 08:14:33',NULL);
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workout_categories`
--

LOCK TABLES `workout_categories` WRITE;
/*!40000 ALTER TABLE `workout_categories` DISABLE KEYS */;
INSERT INTO `workout_categories` VALUES (1,'fb099c5c-f580-4338-994c-b249d9974c71','program',NULL,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),(2,'d30d0e0a-2dec-4755-81fd-55a6708e1dcc','muscles group',NULL,1,'2021-10-25 17:28:07',1,'2021-10-25 17:28:07',NULL),(3,'940ca098-913c-4609-a69f-ccfd5d654efe','focus',NULL,1,'2021-10-25 17:28:08',1,'2021-10-25 17:28:08',NULL),(4,'f7236d05-a9ea-4cb0-b430-7521a7c25f4b','goals',NULL,1,'2021-10-25 17:28:08',1,'2021-10-25 17:28:08',NULL);
/*!40000 ALTER TABLE `workout_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workout_sub_categories`
--

LOCK TABLES `workout_sub_categories` WRITE;
/*!40000 ALTER TABLE `workout_sub_categories` DISABLE KEYS */;
INSERT INTO `workout_sub_categories` VALUES (1,'13d683a9-df99-4289-ae95-7431d099c6ce','Beginner',NULL,1,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(2,'4079d003-82a5-46bb-a9e0-39a5d4a7ddaa','Intermediate',NULL,1,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(3,'ba3f2418-88be-4afe-9625-fe7653267150','Expert',NULL,1,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(4,'e1872eb7-12d4-4d13-93bb-a8112b25faf0','Abs & Core',NULL,2,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(5,'5d900e18-3090-44d6-b855-f04411cbd3d3','Chest & Back',NULL,2,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(6,'4df1c810-41b1-41fe-9a86-638407ed42f7','Arms & Shoulder',NULL,2,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(7,'2e2558fb-e52b-4d88-b6ba-069997581596','Glutes & Legs',NULL,2,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(8,'49e8443e-8b3c-4f30-a92c-8ad51f6ae451','Strength',NULL,3,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(9,'6f1b8b14-668f-4495-801a-1b27860c5cbd','Nordic Skiing',NULL,3,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(10,'825d5794-0d7d-48aa-8c9a-8d41c6431462','Balance',NULL,3,1,'2021-10-25 17:28:06',1,'2021-10-25 17:28:06',NULL),
(11,'3229bec5-da2e-4f55-a79c-00341717a2a6','HIIT',NULL,3,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(12,'3229bec5-da2e-4f55-a79c-00341717a2c9','Lose weight',NULL,4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(13,'8282a498-74fa-4b8f-9790-74d590cbcec1','Improve performance','',4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(14,'d374b9b2-fda3-455c-8a68-09c1c8ebdd4e','Maintain current fitness',NULL,4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(15,'c68f9bb9-7a93-4363-92d3-e3f468dcb0b3','Improve muscle tone',NULL,4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(16,'64796f00-7e33-4c98-8cde-ff069bb609be','Learn nordic trainer technique',NULL,4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL),
(17,'13b802b6-2ba1-4f18-95ca-964cd5ba4fb5','Cross country skiing',NULL,4,1,'2021-11-11 12:11:06',1,'2021-11-11 12:11:06',NULL);
/*!40000 ALTER TABLE `workout_sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
--
-- Dumping data for table `workout_categories`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'ab0da576-0ba3-4846-a4a8-a89dc829310d','pound','lbs',1,'2021-10-19 20:08:04',NULL,'2021-10-19 20:08:04',NULL),(2,'89ca67b5-181c-4fa7-aaf3-b843646d60c4','feet','ft',1,'2021-10-19 20:08:05',NULL,'2021-10-19 20:08:05',NULL),(3,'614bcbbc-c1a9-47ac-83d6-b0ddcf40e281','kilogram','kg',1,'2021-10-20 16:44:44',NULL,'2021-10-20 16:44:44',NULL),(4,'3de9e20f-6a45-4cb5-8912-838e4a41ce2a','centimeter','cm',1,'2021-10-20 16:44:45',NULL,'2021-10-20 16:44:45',NULL);
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;




LOCK TABLES `login_account_types` WRITE;
/*!40000 ALTER TABLE `login_account_types` DISABLE KEYS */;
INSERT INTO `login_account_types` VALUES (1, '3dfc6ec6-4562-11ec-81d3-0242ac130003', 'facebook', 1, '2021-10-25 17:28:07', NULL, '2021-10-25 17:28:07', NULL), (2, '3dfc7362-4562-11ec-81d3-0242ac130003', 'google', 1, '2021-10-25 17:28:07', NULL, '2021-10-25 17:28:07', NULL), (3, '3dfc72ae-4562-11ec-81d3-0242ac130003', 'apple', 1, '2021-10-25 17:28:07', NULL, '2021-10-25 17:28:07', NULL), (4, '3dfc71e6-4562-11ec-81d3-0242ac130003', 'default', 1, '2021-10-25 17:28:07', NULL, '2021-10-25 17:28:07', NULL), (5, '3dfc70f6-4562-11ec-81d3-0242ac130003', 'admin', 1, '2021-10-25 17:28:07', NULL, '2021-10-25 17:28:07', NULL); 
/*!40000 ALTER TABLE `login_account_types` ENABLE KEYS */;
UNLOCK TABLES;  
--
-- Dumping data for table `statuses`
--


-- Dump completed on 2021-10-28 15:29:40
--
-- Dumping data for table `measurement_system_units`
--

LOCK TABLES `measurement_system_units` WRITE;
/*!40000 ALTER TABLE `measurement_system_units` DISABLE KEYS */;
INSERT INTO `measurement_system_units` VALUES (1,2,1,2,1,'2021-10-19 21:03:25',NULL,'2021-10-19 21:03:25',NULL),(2,2,2,1,1,'2021-10-19 21:03:25',NULL,'2021-10-19 21:03:25',NULL),(3,1,1,4,1,'2021-10-20 12:59:16',NULL,'2021-10-20 12:59:16',NULL),(4,1,2,3,1,'2021-10-20 12:59:17',NULL,'2021-10-20 12:59:17',NULL);
UNLOCK TABLES;

LOCK TABLES `measurement_systems` WRITE;
/*!40000 ALTER TABLE `measurement_systems` DISABLE KEYS */;
INSERT INTO `measurement_systems` VALUES (1,'29a5b4f4-fda2-49e8-9a78-4bb17dc44fb4','Metric',1,'2021-10-11 13:35:37',NULL,'2021-10-11 13:35:37',NULL),(2,'bb5bdf62-867f-4d9e-8ea9-bb3f38a7d3b6','US Standard',1,'2021-10-12 16:15:00',NULL,'2021-10-12 16:15:00',NULL);
/*!40000 ALTER TABLE `measurement_systems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `physical_parameters`
--

LOCK TABLES `physical_parameters` WRITE;
/*!40000 ALTER TABLE `physical_parameters` DISABLE KEYS */;
INSERT INTO `physical_parameters` VALUES (1,'8b791009-ac91-4ab2-a2b6-053edd53f7e4','height','',1,'2021-10-19 20:29:16',NULL,'2021-10-19 20:29:16',NULL),(2,'d6f1e09f-6adc-4cf0-a36e-830b1bc5970f','weight','',1,'2021-10-19 20:29:17',NULL,'2021-10-19 20:29:17',NULL);
/*!40000 ALTER TABLE `physical_parameters` ENABLE KEYS */;
UNLOCK TABLES;



--
-- Dumping data for table `workout_duration_types`
--

LOCK TABLES `workout_duration_types` WRITE;
/*!40000 ALTER TABLE `workout_duration_types` DISABLE KEYS */;
INSERT INTO `workout_duration_types` VALUES (1,'b78495eb-120c-41b6-8952-00f01d804a95','0-15 min',NULL,1,'2021-10-11 13:35:38',1,'2021-10-11 13:35:38',1),(2,'fbdf91df-2a02-4080-b9b5-6a3e0c92dfa3','15-30 min',NULL,1,'2021-10-12 16:15:01',1,'2021-10-12 16:15:01',1),(3,'d991596c-0283-4be7-a014-45f174f3e968','30-45 min',NULL,1,'2021-10-12 12:30:48',1,'2021-10-12 12:30:48',1),(4,'b2d76c0c-af7f-4740-8338-2cdc34efc09e','1h',NULL,1,'2021-10-13 09:21:24',1,'2021-10-13 09:21:24',1),(5,'4b73d68a-0312-473b-a5dd-76203286ea1a','more than 1h',NULL,1,'2021-10-15 09:52:00',1,'2021-10-15 09:52:00',1);
/*!40000 ALTER TABLE `workout_duration_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workout_frequency_types`
--

LOCK TABLES `workout_frequency_types` WRITE;
/*!40000 ALTER TABLE `workout_frequency_types` DISABLE KEYS */;
INSERT INTO `workout_frequency_types` VALUES (1,'91929ecd-ff74-4838-92f9-5b1499f18985','per day',NULL,1,'2021-10-11 13:35:38',1,'2021-10-11 13:35:38',1),(2,'54cb58e2-4da6-4284-a31f-5bd22484eded','per week',NULL,1,'2021-10-12 16:15:02',1,'2021-10-12 16:15:02',1),(3,'6fba4af1-d39c-4a1e-8ac9-1dfe4a73aa7d','per month',NULL,1,'2021-10-12 12:30:48',1,'2021-10-12 12:30:48',1);
/*!40000 ALTER TABLE `workout_frequency_types` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'80e7a9e8-2f11-48e0-9ce2-1de825cb2f7d','User',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(2,'f631e322-9048-4a68-8dca-0dc06aefe6d7','Admin',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(5,'852ccc20-3755-11ec-8d3d-0242ac130003','Trainee',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(6,'852ccd06-3755-11ec-8d3d-0242ac130003','Consultant',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(7,'852cce5a-3755-11ec-8d3d-0242ac130003','DBA',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(8,'852ccfe0-3755-11ec-8d3d-0242ac130003','Architect',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(9,'852cd0bc-3755-11ec-8d3d-0242ac130003','DB Manager',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL),(10,'852cd17a-3755-11ec-8d3d-0242ac130003','Developer',1,'2021-10-27 12:06:58',NULL,'2021-10-27 12:06:58',NULL);
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `query_types`
--

LOCK TABLES `query_types` WRITE;
/*!40000 ALTER TABLE `query_types` DISABLE KEYS */;
INSERT INTO `query_types` VALUES (1,'6f92b26d-dbff-45e6-b162-e7da1bc072b3','Report an Issue',NULL,1,'2021-11-25 15:08:52',NULL,'2021-11-25 15:08:52',1),(2,'8c92b26d-dbff-45e6-b162-e7da1bc075e6','FAQ',NULL,1,'2021-11-25 15:08:52',NULL,'2021-11-25 15:08:52',1),(3,'5dff4e6e-b41f-4927-8bf2-5a36fd51d4f8','Privacy policy',NULL,1,'2021-11-25 15:08:52',NULL,'2021-11-25 15:08:52',NULL);
/*!40000 ALTER TABLE `query_types` ENABLE KEYS */;
UNLOCK TABLES;