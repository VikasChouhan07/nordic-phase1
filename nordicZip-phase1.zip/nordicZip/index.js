const express = require("express");
const app = express();
require("dotenv-flow").config();
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");
const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
let swaggerDefinition = require("./swagger/swaggerDefinition");

// For uploading multimedia files
const fileUpload = require("express-fileupload");

// Import Own Defined Modules
const routes = require("./src/routes");
const routesV2 = require("./src/routesV2");

// App Configuration
app.use(cors());
app.use(fileUpload());
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));

// Extended: https://swagger.io/specification/#infoObject
const swaggerOptionsOne = {
  swaggerDefinition,
  apis: ["routes.js"],
};
//Swagger for version 2
swaggerDefinition = require("./swagger/swaggerDefinitionV2");
const swaggerDocs = swaggerJsDoc(swaggerOptionsOne);
const swaggerOptionsTwo = {
  swaggerDefinition,
  apis: ["routesV2.js"],
};
const swaggerDocsV2 = swaggerJsDoc(swaggerOptionsTwo);

app.use("/api", routes); // Assigning Defined Routes
app.use("/api", routesV2); // Assigning Defined Routes
app.use(express.static(path.join(__dirname, "public")));

app.use(
  "/api-docs",
  swaggerUi.serveFiles(swaggerDocs, swaggerOptionsOne),
  swaggerUi.setup(swaggerDocs)
);

app.use(
  "/api-docs-v2",
  swaggerUi.serveFiles(swaggerDocsV2, swaggerOptionsTwo),
  swaggerUi.setup(swaggerDocsV2)
);

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(
    `Nordic Strong services application listening at http://localhost:${port}`
  );
});
