const users = require("./docs/users/index");
const admins = require("./docs/admin/index");
const workoutVideos = require("./docs/workoutVideos/index");
const workoutRecommendation = require("./docs/workoutRecommendation/index");
const reportsAndfaqs = require("./docs/reportsAndFaqs/index");
const workoutPlans = require("./docs/workoutPlans/index");
const swaggerDefinition = {
  openapi: "3.0.3",
  info: {
    title: "Nordic Strong - APIs",
    description: "This includes Nordic Strong App APIs.",
    contact: {
      name: "Debut Infotech",
    },
    version: "1.0.0",
  },
  paths: {
    ...users,
    ...admins,
    ...workoutVideos,
    ...reportsAndfaqs,
    ...workoutRecommendation,
    ...workoutPlans,
  },
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
      },
    },
  },
  security: [
    {
      bearerAuth: [],
    },
  ],
};

module.exports = swaggerDefinition;
