const {
  components: {
    schemas: {
      Error,
      recommendationInput,
      getRecommendationId,
      getRecommendedInput,
      getRecommendationsResponse,
      getRecommendationFilters,
      getUserUuid,
      getTodaysRecommendationsResponse,
      getPublishRecommendedInput,
      getRecommendationPublishDate,
    },
  },
} = require("./components");
const userPaths = {
  "/api/V2/recommendations": {
    post: {
      tags: ["Workout Recommendation"],
      summary: "Add Recommendation",
      description: "Add Recommendation",
      operationId: "addRecommendation",
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: recommendationInput,
          },
        },
      },
      responses: {
        201: {
          description: "Recommendation Created Successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
    get: {
      tags: ["Workout Recommendation"],
      summary: "Get All Recommendations",
      description: "Get Stores",
      operationId: "getRecommendation",
      parameters: getRecommendationFilters,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getRecommendationsResponse,
            },
          },
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/recommendations/{id}": {
    put: {
      tags: ["Workout Recommendation"],
      summary: "Edit Recommendation",
      description: "Edit Recommendation",
      operationId: "editrecommendation",
      parameters: getRecommendationId,
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: recommendationInput,
          },
        },
      },
      responses: {
        201: {
          description: "Recommendation Created Successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/V2/recommendation/{uuid}": {
    get: {
      tags: ["Workout Recommendation"],
      summary: "Get Today's Workout Recommendation",
      description: "Get Workout Recommendation for admin based on uuid",
      operationId: "getWorkoutRecommendation",
      parameters: getRecommendedInput,
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Error",
        },
      },
    },
    delete: {
      tags: ["Workout Recommendation"],
      summary: "Delete Recommendation",
      description: "Delete Stores",
      operationId: "deleteRecommendation",
      parameters: getRecommendedInput,
      responses: {
        200: {
          description: "Recommendation deleted successfully.",
        },
        402: {
          description: "An error has occurred while deleting Recommendation.",
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/recommendations/{uuid}/publish/{publish}": {
    patch: {
      tags: ["Workout Recommendation"],
      summary: "Publish/Un-Published Recommendation",
      description: "Publish Recommendation",
      operationId: "publishrecommendation",
      parameters: getPublishRecommendedInput,
      requestBody: {
        required: true,
        content: {
          "multipart/form-data": {
            schema: getRecommendationPublishDate,
          },
        },
      },
      responses: {
        200: {
          description: "Recommendation Published / Un-Published successfully.",
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/recommendations/user/{userUuid}": {
    get: {
      tags: ["Workout Recommendation"],
      summary: "Get Todays Recommendation",
      description: "Get Today's Recommendation for user",
      operationId: "getTodaysRecommendation",
      parameters: getUserUuid,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getTodaysRecommendationsResponse,
            },
          },
        },
        404: {
          description: "Recommendation not found!",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
};

module.exports = userPaths;
