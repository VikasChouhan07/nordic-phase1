const {
  components: {
    schemas: {
      Error,
      addWorkoutPlans,
      getPlansFilters,
      getPlansResponse,
      getPlanInput,
      getPlanResponse,
      getUuidInput,
      getPlanUuid,
    },
  },
} = require("./components");
const userPaths = {
  "/api/V2/workout-plans": {
    post: {
      tags: ["Workout Plans"],
      summary: "Add workout plan",
      description: "Post Stores",
      operationId: "addWorkoutPlan",
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: addWorkoutPlans,
          },
        },
      },
      responses: {
        201: {
          description: "Created",
        },
        500: {
          description: "Error",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
    get: {
      tags: ["Workout Plans"],
      summary: "Get All Plans",
      description: "Get Stores",
      operationId: "getPlans",
      parameters: getPlansFilters,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getPlansResponse,
            },
          },
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/workout-plans/{uuid}": {
    put: {
      tags: ["Workout Plans"],
      summary: "Edit workout plan",
      description: "Post Stores",
      operationId: "editWorkoutPlan",
      parameters: getUuidInput,
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: addWorkoutPlans,
          },
        },
      },
      responses: {
        201: {
          description: "Created",
        },
        500: {
          description: "Error",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
    delete: {
      tags: ["Workout Plans"],
      summary: "Delete Plan",
      description: "Delete Stores",
      operationId: "deletePlan",
      parameters: getUuidInput,
      responses: {
        200: {
          description: "Plan deleted successfully.",
        },
        402: {
          description: "An error has occurred while deleting Plan!",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
  "/api/V2/workout-plans/plan/{planUuid}": {
    get: {
      tags: ["Workout Plans"],
      summary: "Get Workout Plan",
      description: "Get Workout Plan",
      operationId: "getPlanDetails",
      parameters: getPlanInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getPlanResponse,
            },
          },
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/V2/saved-workout-plans": {
    post: {
      tags: ["Workout Plans"],
      summary: "Save Plan",
      description: "Save Plan",
      operationId: "savePlan",
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: getPlanUuid,
          },
        },
      },
      responses: {
        200: {
          description: "Plan has been saved/unsaved successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
};

module.exports = userPaths;
