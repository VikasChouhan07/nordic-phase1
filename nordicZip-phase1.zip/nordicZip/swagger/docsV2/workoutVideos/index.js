const {
  components: {
    schemas: {
      Error,
      addWorkoutVideos,
      getWorkoutResponse,
      getUsersInput,
      getWorkoutInput,
      getWorkoutTypeInput,
      WorkoutVideosUuids,
      featuredInput,
      getStatusInput,
      getUserInput,
      getSavedWorkoutsResponse,
      getWorkoutHistoryInput,
      getScheduleWorkoutInput,
      getWorkoutVideoInput,
      getBestTimeInput,
    },
  },
} = require("./components");
const userPaths = {
  "/api/V2/workout-videos": {
    post: {
      tags: ["Workout Videos"],
      summary: "Add workouts",
      description: "Post Stores",
      operationId: "addWorkoutDetails",
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: addWorkoutVideos,
          },
        },
      },
      responses: {
        201: {
          description: "Created",
        },
        500: {
          description: "Error",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
    get: {
      tags: ["Workout Videos"],
      summary: "Get workouts",
      description: "Get Stores",
      operationId: "getWorkoutVideos",
      parameters: getUsersInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getWorkoutResponse,
            },
          },
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
    delete: {
      tags: ["Workout Videos"],
      summary: "Delete workouts",
      description: "Delete Stores",
      operationId: "deleteWorkoutVideos",
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: WorkoutVideosUuids,
          },
        },
      },
      responses: {
        200: {
          description: "Video deleted successfully.",
        },
        402: {
          description: "An error has occurred while deleting video.",
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/workout-videos/{uuid}": {
    get: {
      tags: ["Workout Videos"],
      summary: "Get Workout Details",
      description: "Get Workout Details",
      operationId: "getWorkoutDetails",
      parameters: getWorkoutInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getWorkoutResponse,
            },
          },
        },
        500: {
          description: "Error",
        },
      },
    },
    put: {
      tags: ["Workout Videos"],
      summary: "Edit workouts",
      description: "Get Stores",
      operationId: "editWorkoutDetails",
      parameters: getWorkoutInput,
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: addWorkoutVideos,
          },
        },
      },
      responses: {
        201: {
          description: "Created",
        },
        500: {
          description: "Error",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/V2/workout-videos/category/{type}/sub-category-id/{id}": {
    get: {
      tags: ["Workout Videos"],
      summary: "Get workouts",
      description: "Get Stores",
      operationId: "getWorkoutVideosType",
      parameters: getWorkoutTypeInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getWorkoutResponse,
            },
          },
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/workout-videos/featured/{featured}": {
    patch: {
      tags: ["Workout Videos"],
      summary: "Featured / UnFeatured Videos",
      description: "Featured / UnFeatured Videos",
      operationId: "FeaturedUnFeaturedWorkoutVideos",
      parameters: featuredInput,
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: WorkoutVideosUuids,
          },
        },
      },
      responses: {
        200: {
          description: "Video featured / Un-Featured successfully.",
        },
        402: {
          description:
            "An error has occurred while mark video feature / Un-featured.",
        },
        500: {
          description: "Internal server error.",
        },
      },
    },
  },
  "/api/V2/workout-videos/{uuid}/status/{status}": {
    patch: {
      tags: ["Workout Videos"],
      summary: "Update Workout video Status",
      description: "Update Workout video Status",
      operationId: "updateStatus",
      parameters: getStatusInput,
      responses: {
        200: {
          description: "Status has updated successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        422: {
          description: "Invalid User Status Code!",
        },
        204: {
          description: "An error has occured while updating Status!",
        },
      },
    },
  },
  "/api/V2/workout-videos/user/{uuid}": {
    post: {
      tags: ["Workout Videos"],
      summary: "Save workout",
      description: "Save workout",
      operationId: "saveWorkout",
      parameters: getWorkoutInput,
      responses: {
        200: {
          description: "Video has been saved/unsaved successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/V2/workout-videos/user/{userUuid}": {
    get: {
      tags: ["Workout Videos"],
      summary: "Get Saved Workouts",
      description: "Get Saved Workouts",
      operationId: "getSavedWorkout",
      parameters: getUserInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getSavedWorkoutsResponse,
            },
          },
        },
        500: {
          description: "Error",
        },
      },
    },
  },
  "/api/V2/completed-workouts": {
    get: {
      tags: ["Workout Videos"],
      summary: "Get Workouts History",
      description: "Get Workouts History",
      operationId: "getWorkoutHistory",
      parameters: getWorkoutHistoryInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getSavedWorkoutsResponse,
            },
          },
        },
        500: {
          description: "Error",
        },
      },
    },
    post: {
      tags: ["Workout Videos"],
      summary: "Mark Workout Video Completed",
      description: "Mark Workout Video Completed",
      operationId: "markWorkoutVideoCompleted",
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: getWorkoutVideoInput,
          },
        },
      },
      responses: {
        200: {
          description: "Workout has been mark completed successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/V2/planned-workouts": {
    post: {
      tags: ["Workout Videos"],
      summary: "Schedule workout",
      description: "Schedule workout",
      operationId: "scheduleWorkout",
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: getScheduleWorkoutInput,
          },
        },
      },
      responses: {
        200: {
          description: "Workout has been scheduled successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/V2/planned-workouts/user/{userUuid}": {
    get: {
      tags: ["Workout Videos"],
      summary: "Get Scheduled workout",
      description: "Get Scheduled workout",
      operationId: "getScheduledWorkout",
      parameters: getUserInput,
      responses: {
        200: {
          description: "Workout has been scheduled successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
  "/api/v1/user/workout-best-time": {
    post: {
      tags: ["Workout Videos"],
      summary: "Save Best Time",
      description: "Save Best Time",
      operationId: "saveBestTime",
      requestBody: {
        content: {
          // content-type
          "multipart/form-data": {
            schema: getBestTimeInput,
          },
        },
      },
      responses: {
        200: {
          description: "User's Best time has been saved successfully.",
        },
        500: {
          description: "Internal Server Error!",
          content: {
            // content-type
            "application/json": {
              schema: Error,
            },
          },
        },
      },
    },
  },
};

module.exports = userPaths;
