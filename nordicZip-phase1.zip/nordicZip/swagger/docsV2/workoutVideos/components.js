module.exports = {
  components: {
    schemas: {
      // error model
      Error: {
        type: "object", //data type
        properties: {
          message: {
            type: "string", // data type
            description: "Error message", // desc
            example: "Not found", // example of an error message
          },
          internal_code: {
            type: "string", // data type
            description: "Error internal code", // desc
            example: "Invalid parameters", // example of an error internal code
          },
        },
      },
      addWorkoutVideos: {
        type: "object",
        properties: {
          workoutName: {
            type: "string",
            required: "true",
            description: "Name of the workout",
          },
          thumbnail: {
            type: "string",
            format: "binary",
            required: "true",
            description: "Thumbnail of the video",
          },
          video: {
            type: "string",
            format: "binary",
            required: "true",
            description: "Video to be uploaded",
          },
          programs: {
            type: "array",
            required: "true",
            description: "ID of Workout programs",
          },
          muscleGroups: {
            type: "array",
            required: "true",
            description: "ID of Workout muscles groups",
          },
          focus: {
            type: "array",
            required: "true",
            description: "Workout focuses",
          },
          duration: {
            type: "string",
            required: "true",
            description: "Duration of video",
          },
          instructorName: {
            type: "string",
            required: "true",
            description: "Name of the instructor",
          },
          trainingGoal: {
            type: "array",
            required: "true",
            description: "ID of workout Goals",
          },
          description: {
            type: "string",
            required: "true",
            description: "Description of video",
          },
        },
      },
      getWorkoutInput: [
        {
          in: "path",
          name: "uuid",
          schema: {
            type: "string",
          },
          description: "uuid of the Workout Video",
        },
      ],
      getWorkoutVideoInput: {
        type: "object",
        properties: {
          workoutVideoId: {
            type: "integer",
            required: "true",
            description: "id of workout video",
          },
        },
      },
      getUsersResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "object",
            properties: {
              records: {
                type: "array",
                items: {
                  type: "object",
                  properties: {},
                },
              },
              totalCount: { type: "integer" },
              page: { type: "integer" },
              pageSize: { type: "integer" },
              uuid: {
                type: "integer", // data type
                description: "An id of a workout", // desc
              },
              name: { type: "string" },
              description: { type: "string" },
              workout_videos: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                    savedLocation: { type: "string" },
                    size: { type: "string" },
                    duration: { type: "string" },
                    video_thumbnail: {
                      type: "object",
                      properties: {
                        filename: { type: "string" },
                        savedLocation: { type: "string" },
                      },
                    },
                    workout_instructor: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                      },
                    },
                  },
                },
              },
              workout_video_details: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "string" },
                    workout_category: {
                      type: "object",
                      properties: {
                        uuid: { type: "string" },
                        name: { type: "string" },
                      },
                    },
                    workout_sub_category: {
                      type: "object",
                      properties: {
                        uuid: { type: "string" },
                        name: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
          message: { type: "string" },
        },
      },
      getWorkoutResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: {
                  type: "integer", // data type
                  description: "An id of a workout video", // desc
                },
                description: { type: "string" },
                savedLocation: { type: "string" },
                size: { type: "string" },
                duration: { type: "string" },
                workout_id: { type: "integer" },
                workout_uuid: { type: "string" },
                workout_name: { type: "string" },
                workout_description: { type: "string" },
                workout_programs: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
                workout_focuses: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
                workout_muscle_groups: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
                workout_goals: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
                workout_instructor: { type: "string" },
                video_thumbnail: { type: "string" },
              },
            },
          },
        },
        message: { type: "string" },
      },
      getWorkoutTypeInput: [
        {
          in: "path",
          name: "type",
          schema: {
            type: "string",
          },
          description:
            "Type of workout videos possible values:- userMightLike | program | muscleGroup | focusList",
        },
        {
          in: "path",
          name: "id",
          schema: {
            type: "string",
          },
          description: "ID of sub-category",
        },
        {
          in: "query",
          name: "page",
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
      ],
      getUsersInput: [
        {
          in: "query",
          name: "page",
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "query",
          name: "search",
          schema: {
            type: "string",
          },
          description: "Enter the Name of workout or Name of instructor",
        },
        {
          in: "query",
          name: "sortBy",
          schema: {
            type: "string",
          },
          description: '[{"id":"username","desc":true}]',
        },
        {
          in: "query",
          name: "isFeatured",
          schema: {
            type: "Integer",
          },
          description: "Enter 1 to get featured workout videos",
        },
      ],
      WorkoutVideosUuids: {
        type: "object",
        properties: {
          uuids: {
            type: "array",
            required: "true",
            description: "UUIDs of workout videos",
          },
        },
      },
      featuredInput: [
        {
          in: "path",
          name: "featured",
          schema: {
            type: "string",
          },
          description: "feature or unfeature video by (1/0)",
        },
      ],
      getStatusInput: [
        {
          in: "path",
          name: "uuid",
          schema: {
            type: "string",
          },
          description: "uuid of the Workout Video",
        },
        {
          in: "path",
          name: "status",
          schema: {
            type: "string",
          },
          description: "Status of the workout video",
        },
      ],
      getUserInput: [
        {
          in: "query",
          name: "page",
          required: true,
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          required: true,
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "path",
          name: "userUuid",
          required: true,
          schema: {
            type: "string",
          },
          description: "uuid of the user",
        },
      ],
      getWorkoutHistoryInput: [
        {
          in: "query",
          name: "page",
          required: true,
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          required: true,
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
      ],
      getSavedWorkoutsResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: {
                  type: "integer", // data type
                  description: "An id of a workout video", // desc
                },
                workout_video: {
                  type: "object",
                  properties: {
                    uuid: { type: "string" },
                    workout: {
                      type: "object",
                      properties: {
                        workout_name: { type: "string" },
                        workout_video_details: {
                          type: "array",
                          items: {
                            properties: {
                              workout_category: { type: "string" },
                              workout_sub_category: { type: "string" },
                            },
                          },
                        },
                      },
                    },
                  },
                },
                workout_programs: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
                workout_instructor: { type: "string" },
                video_thumbnail: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                  },
                },
              },
            },
          },
        },
        message: { type: "string" },
      },
      getScheduleWorkoutInput: {
        type: "object",
        properties: {
          uuid: {
            type: "string",
            required: "true",
            description: "uuid of workout video",
          },
          plannedDate: {
            type: "date",
            required: "true",
            description: "Planned date for workout",
          },
        },
      },
      getBestTimeInput: {
        type: "object",
        properties: {
          distanceCovered: {
            type: "integer",
            required: "true",
            description: "Distance covered by user in meters.",
          },
          bestTime: {
            type: "integer",
            required: "true",
            description: "In how much time(seconds) Distance covered.",
          },
        },
      },
    },
  },
};
