const users = require("./docsV2/users/index");
const admins = require("./docsV2/admin/index");
const workoutVideos = require("./docsV2/workoutVideos/index");
const workoutRecommendation = require("./docsV2/workoutRecommendation/index");
const reportsAndfaqs = require("./docsV2/reportsAndFaqs/index");
const workoutPlans = require("./docsV2/workoutPlans/index");
const swaggerDefinition = {
  openapi: "3.0.3",
  info: {
    title: "Nordic Strong - APIs Version-2",
    description: "This includes Nordic Strong App APIs.",
    contact: {
      name: "Debut Infotech",
    },
    version: "2.0.0",
  },
  paths: {
    ...users,
    ...admins,
    ...workoutVideos,
    ...reportsAndfaqs,
    ...workoutRecommendation,
    ...workoutPlans,
  },
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
      },
    },
  },
  security: [
    {
      bearerAuth: [],
    },
  ],
};

module.exports = swaggerDefinition;
