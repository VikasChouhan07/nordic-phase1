const {
  components: {
    schemas: {
      getUsersResponse,
      getUserResponse,
      getUsersInput,
      getUserInput,
      getPasswordInput,
      getUsersInPathParameters,
      getAdminProfileDetails,
      getEmailInputs,
      getOtpVerificationInput,
      getUserProfileDetailsRequest,
      getResetPasswordInput,
      getVerifyOtpResponse,
      getUserLogin,
    },
  },
} = require("./components");
const userPaths = {
  "/api/v1/login": {
    post: {
      tags: ["Users"],
      summary: "User Login",
      description: "user login",
      operationId: "userLogin",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getUserLogin,
          },
        },
      },
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Error",
        },
      },
    },
  },
  "/api/v1/signup": {
    post: {
      tags: ["Users"],
      summary: "Signup a User",
      description: "Post Stores",
      operationId: "postUser",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                name: {
                  type: "string",
                  required: "true",
                  description: "Name of the user",
                },
                email: {
                  type: "string",
                  required: "true",
                  description: "Email Address of the user",
                },
                password: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                measurementSystem: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                height: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                gender: {
                  type: "string",
                  required: "true",
                  description: "Gender of the user",
                },
                weight: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                trainingGoal: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                workoutFrequency: {
                  type: "string",
                  required: "true",
                  description: "Number of times user workouts",
                },
                workoutFrequencyType: {
                  type: "string",
                  required: "true",
                  description:
                    "Id of time period unit in which user does workouts per day/per week/per month",
                },
                workoutDuration: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
              },
            },
          },
        },
      },
      responses: {
        201: {
          description: "Success",
        },
        500: {
          description: "Internal server error",
        },
        400: {
          description: "Validation error",
        },
      },
    },
  },
  "/api/v1/onboarding-details": {
    post: {
      tags: ["Users"],
      summary: "Add Onboarding details of User",
      description: "Post Stores",
      operationId: "postOnboardingData",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                measurementSystem: {
                  type: "string",
                  required: "true",
                  description: "ID of Measurement system of the user",
                },
                height: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
                weight: {
                  type: "string",
                  required: "true",
                  description: "Weight of the user",
                },
                gender: {
                  type: "string",
                  required: "true",
                  description: "Gender of the user",
                },
                trainingGoal: {
                  type: "string",
                  required: "true",
                  description: "ID of training goal of the user",
                },
                workoutFrequency: {
                  type: "string",
                  required: "true",
                  description: "Number of times user workouts",
                },
                workoutFrequencyType: {
                  type: "string",
                  required: "true",
                  description:
                    "ID of time period unit in which user does workouts per day/per week/per month",
                },
                workoutDuration: {
                  type: "string",
                  required: "true",
                  description: "ID of Workout duration",
                },
              },
            },
          },
        },
      },
      responses: {
        201: {
          description: "Success",
        },
        500: {
          description: "Internal server error",
        },
        400: {
          description: "Validation error",
        },
      },
    },
  },
  "/api/v1/logout": {
    post: {
      tags: ["Users"],
      summary: "User Logout",
      description: "User logout",
      operationId: "userLogout",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: {
              type: "object",
              required: ["deviceId"],
              properties: {
                deviceId: {
                  type: "string",
                  description: "Device ID",
                },
              },
            },
          },
        },
      },
      responses: {
        200: {
          description: "Success",
        },
        422: {
          description: "Invalid Credentials",
        },
        500: {
          description: "Internal server error",
        },
      },
    },
  },
  "/api/v1/refresh-token": {
    post: {
      tags: ["Users"],
      summary: "Refresh token",
      description: "Refresh the token if previous has been expired",
      operationId: "refreshToken",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: {
              type: "object",
              required: ["token"],
              properties: {
                token: {
                  type: "string",
                  description: "Old Token",
                },
              },
            },
          },
        },
      },
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Error",
        },
      },
    },
  },
  "/api/v1/users": {
    post: {
      tags: ["Users"],
      summary: "Create a User",
      description: "Post Stores",
      operationId: "postUsers",
      requestBody: {
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                firstName: {
                  type: "string",
                  required: "true",
                  description: "First Name of the user",
                },
                lastName: {
                  type: "string",
                  required: "true",
                  description: "last Name of the user",
                },
                username: {
                  type: "string",
                  required: "true",
                  description: "username of the user",
                },
                email: {
                  type: "string",
                  required: "true",
                  description: "Email Address of the user",
                },
                password: {
                  type: "string",
                  required: "true",
                  description: "Password of the user",
                },
              },
            },
          },
        },
      },
      responses: {
        201: {
          description: "Created",
        },
      },
    },
    get: {
      tags: ["Users"],
      summary: "Get users",
      description: "Get Stores",
      operationId: "getUsers",
      parameters: getUsersInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getUsersResponse,
            },
          },
          500: {
            description: "Error",
          },
          400: {
            description: "Validation Error",
          },
        },
      },
    },
  },
  "/api/v1/users/{uuid}": {
    get: {
      tags: ["Users"],
      summary: "Get users",
      description: "Get Stores",
      operationId: "getUserDetail",
      parameters: getUserInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getUserResponse,
            },
          },
        },
        500: {
          description: "Error",
        },
      },
    },
    put: {
      tags: ["Users"],
      summary: "Update User Profile",
      description: "User Profile Update",
      operationId: "userProfileUpdate",
      parameters: getUserInput,
      requestBody: {
        content: {
          "multipart/form-data": {
            schema: getUserProfileDetailsRequest,
          },
        },
      },
      responses: {
        200: {
          description: "Profile Updated Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        204: {
          description: "Error occurred while updating profile!",
        },
        403: {
          description: "Validation errors!",
        },
      },
    },
  },
  "/api/v1/users/{uuid}/email": {
    patch: {
      tags: ["Users"],
      summary: "Update Admin Email",
      description: "Admin Profile Email",
      operationId: "adminEmailUpdate",
      parameters: getUserInput,
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getEmailInputs,
          },
        },
      },
      responses: {
        200: {
          description: "Email Updated Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        402: {
          description: "An Error occurred while updating email!",
        },
        403: {
          description: "Validation errors!",
        },
      },
    },
  },
  "/api/v1/users/{uuid}/change-password": {
    post: {
      tags: ["Users"],
      summary: "Change Password",
      description: "Change Password",
      operationId: "changePassword",
      parameters: getUserInput,
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getPasswordInput,
          },
        },
      },
      responses: {
        200: {
          description: "Password Updated Successfully",
        },
        500: {
          description: "Error",
        },
      },
    },
  },
  "/api/v1/users/{uuid}/reset-password": {
    put: {
      tags: ["Users"],
      summary: "Reset Password",
      description: "Reset Password",
      operationId: "resetPassword",
      parameters: getUserInput,
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getResetPasswordInput,
          },
        },
      },
      responses: {
        200: {
          description: "Password Reset Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/otp-verify": {
    post: {
      tags: ["Users"],
      summary: "OTP Verify",
      description: "OTP Verify",
      operationId: "Otpverify",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getOtpVerificationInput,
          },
        },
      },
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getVerifyOtpResponse,
            },
          },
        },
        500: {
          description: "Internal Server Error!",
        },
        400: {
          description: "Invalid OTP!",
        },
        401: {
          description: "OTP has been expired!",
        },
      },
    },
  },
  "/api/v1/otp/{email}": {
    get: {
      tags: ["Users"],
      summary: "Get Otp",
      description: "Get Stores",
      operationId: "getOtp",
      parameters: getUsersInPathParameters,
      responses: {
        201: {
          description: "Success",
        },
        422: {
          description: "Invalid Credentials!",
        },
        500: {
          description: "Internal server error",
        },
      },
    },
  },
  "/api/v1/otp-admin/{email}": {
    get: {
      tags: ["Users"],
      summary: "Get Otp",
      description: "Get Stores",
      operationId: "getAdminOtp",
      parameters: getUsersInPathParameters,
      responses: {
        201: {
          description: "Success",
        },
        422: {
          description: "Invalid Credentials!",
        },
        500: {
          description: "Internal server error",
        },
      },
    },
  },
  "/api/v1/otp/{email}/type/new-email": {
    get: {
      tags: ["Users"],
      summary: "Get Otp",
      description: "Get Stores",
      operationId: "getNewUserOtp",
      parameters: getUsersInPathParameters,
      responses: {
        201: {
          description: "Success",
        },
        422: {
          description: "Invalid Credentials!",
        },
        500: {
          description: "Internal Server Error",
        },
      },
    },
  },
  "/api/v1/admins/{uuid}": {
    put: {
      tags: ["Users"],
      summary: "Update Admin Profile",
      description: "Admin Profile Update",
      operationId: "adminProfileUpdate",
      parameters: getUserInput,
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getAdminProfileDetails,
          },
        },
      },
      responses: {
        200: {
          description: "Profile Updated Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        204: {
          description: "An error has occurred while updating profile!",
        },
        403: {
          description: "Validation errors!",
        },
      },
    },
  },
  "/api/v1/programs": {
    get: {
      tags: ["Programs"],
      summary: "Get Programs",
      description: "Get Stores",
      operationId: "getPrograms",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/muscle-groups": {
    get: {
      tags: ["Programs"],
      summary: "Get Muscle Groups",
      description: "Get Stores",
      operationId: "getMuscles",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/training-goals": {
    get: {
      tags: ["Programs"],
      summary: "Get Training Goals",
      description: "Get Stores",
      operationId: "getTrainingGoals",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/focuses": {
    get: {
      tags: ["Programs"],
      summary: "Get Focuses",
      description: "Get Stores",
      operationId: "getFocuses",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/measurement-systems": {
    get: {
      tags: ["Programs"],
      summary: "Get Measurement System",
      description: "Get Stores",
      operationId: "getMeasurement",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/workout-frequency-types": {
    get: {
      tags: ["Programs"],
      summary: "Get workout frequency types",
      description: "Get Stores",
      operationId: "getFrequencies",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
  "/api/v1/workout-duration-types": {
    get: {
      tags: ["Programs"],
      summary: "Get workout duration types",
      description: "Get Stores",
      operationId: "getWorkoutDuration",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal Server Error!",
        },
      },
    },
  },
};

module.exports = userPaths;
