module.exports = {
  components: {
    schemas: {
      getFaqResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "object",
            properties: {
              faqs: {
                items: {
                  //type: "object",
                  properties: {
                    question: { type: "string" },
                    answer: { type: "string" },
                    status: { type: "string" },
                  },
                },
              },
            },
          },
          message: { type: "string" },
        },
      },
      getFaqInputs: {
        type: "object",
        required: ["question", "answer", "status"],
        properties: {
          question: {
            type: "string",
            description: "Question",
          },
          answer: {
            type: "string",
            description: "Answer",
          },
          status: {
            type: "string",
            description: "Status",
          },
        },
      },
      getFaqInput: [
        {
          in: "query",
          name: "page",
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "query",
          name: "search",
          schema: {
            type: "string",
          },
          description: "Enter the Question to search",
        },
        {
          in: "query",
          name: "status",
          schema: {
            type: "string",
          },
          description: "The Status you have selected is Invalid.",
        },
      ],
      getFaqId: [
        {
          in: "path",
          name: "id",
          schema: {
            type: "string",
          },
          description: "id of the faq",
        },
      ],
      getQueryId: [
        {
          in: "path",
          name: "id",
          required: true,
          schema: {
            type: "string",
          },
          description: "Id of the Query",
        },
      ],
      getQueryInput: [
        {
          in: "path",
          name: "id",
          required: true,
          schema: {
            type: "string",
          },
          description: "id of the Issue",
        },
        {
          in: "path",
          name: "resolved",
          required: true,
          schema: {
            type: "string",
          },
          description: "Resolved or Unresolved Query",
        },
      ],
      getQueriesResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "object",
            properties: {
              records: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: {
                      type: "integer", // data type
                      description: "An id of a user", // desc
                    },
                    firstName: { type: "string" },
                    lastName: { type: "string" },
                    email: { type: "string" },
                    username: { type: "string" },
                    registrationDate: { type: "date" },
                  },
                },
              },
              totalCount: { type: "integer" },
              page: { type: "integer" },
              pageSize: { type: "integer" },
            },
          },
          message: { type: "string" },
        },
      },
      getQueriesInput: [
        {
          in: "query",
          name: "page",
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "query",
          name: "search",
          schema: {
            type: "string",
          },
          description: "Enter the Name or the Email ID to search user",
        },
        {
          in: "query",
          name: "isResolved",
          schema: {
            type: "integer",
          },
          description: "Filter form query resolved or unresolved",
        },
        {
          in: "query",
          name: "fromDate",
          schema: {
            type: "date",
          },
          description:
            "Query report 'From Date' is not in correct format.",
        },
        {
          in: "query",
          name: "toDate",
          schema: {
            type: "date",
          },
          description: "Query report 'To Date' is not in correct format.",
        },
      ],
    },
  },
};
