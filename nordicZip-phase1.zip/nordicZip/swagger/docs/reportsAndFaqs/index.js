const {
  components: {
    schemas: {
      getFaqResponse,
      getFaqInputs,
      getFaqInput,
      getFaqId,
      getQueryId,
      getQueryInput,
      getQueriesInput,
      getQueriesResponse,
    },
  },
} = require("./components");
const userPaths = {
  "/api/v1/faqs": {
    post: {
      tags: ["FAQs"],
      summary: "Post FAQs",
      description: "Post FAQs",
      operationId: "postFaqs",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getFaqInputs,
          },
        },
      },
      responses: {
        201: {
          description: "FAQ added successfully.",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
    get: {
      tags: ["FAQs"],
      summary: "Get FAQs",
      description: "Get FAQs",
      operationId: "getFaqs",
      parameters: getFaqInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getFaqResponse,
            },
          },
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
  "/api/v1/faqs/{id}": {
    get: {
      tags: ["FAQs"],
      summary: "Get One FAQ",
      description: "Get One FAQ",
      operationId: "getOneFaq",
      parameters: getFaqId,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getFaqResponse,
            },
          },
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
    delete: {
      tags: ["FAQs"],
      summary: "Delete One FAQ",
      description: "Delete One FAQ",
      operationId: "deleteOneFaq",
      parameters: getFaqId,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getFaqResponse,
            },
          },
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
    put: {
      tags: ["FAQs"],
      summary: "Edit FAQs",
      description: "Edit FAQs",
      operationId: "editFaqs",
      parameters: getFaqId,
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getFaqInputs,
          },
        },
      },
      responses: {
        201: {
          description: "FAQ updated successfully.",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
  "/api/v1/queries": {
    post: {
      tags: ["Report Issues"],
      summary: "Report an Issue",
      description: "Report an Issue",
      operationId: "reportAnIssue",
      requestBody: {
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                subject: {
                  type: "string",
                  required: "true",
                  description: "Subject",
                },
                description: {
                  type: "string",
                  required: "true",
                  description: "Description of report",
                },
              },
            },
          },
        },
      },
      responses: {
        201: {
          description: "Success",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
    get: {
      tags: ["Report Issues"],
      summary: "Get queries",
      description: "Get Stores",
      operationId: "getQueries",
      parameters: getQueriesInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getQueriesResponse,
            },
          },
          500: {
            description: "Internal server error!",
          },
          400: {
            description: "Validation Error",
          },
        },
      },
    },
  },
  "/api/v1/queries/{id}": {
    get: {
      tags: ["Report Issues"],
      summary: "Get Query",
      description: "For getting multiple queries do not send ID",
      operationId: "getQuery",
      parameters: getFaqId,
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
    delete: {
      tags: ["Report Issues"],
      summary: "Delete an Issue",
      description: "Delete an Issue",
      operationId: "deleteAnIssue",
      parameters: getQueryId,
      responses: {
        200: {
          description: "Query has been deleted successfully.",
        },
        402: {
          description: "An error has occurred while deleting query!",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
  "/api/v1/queries/{id}/resolved/{resolved}": {
    patch: {
      tags: ["Report Issues"],
      summary: "Resolved/Unresolved Issues",
      description: "Resolved/Unresolved Issues",
      operationId: "updateQuery",
      parameters: getQueryInput,
      responses: {
        200: {
          description: "Query has benn updated successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        402: {
          description:
            "An error has occured while marking query resolved/unresolved!",
        },
      },
    },
  },
  "/api/v1/privacy-policy": {
    get: {
      tags: ["Privacy Policy"],
      summary: "Get privacy policy",
      description: "Get privacy policy",
      operationId: "getPrivacy",
      responses: {
        200: {
          description: "Success",
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
};

module.exports = userPaths;
