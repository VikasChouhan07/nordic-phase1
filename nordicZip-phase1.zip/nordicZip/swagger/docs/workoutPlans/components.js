module.exports = {
  components: {
    schemas: {
      // error model
      Error: {
        type: "object", //data type
        properties: {
          message: {
            type: "string", // data type
            description: "Error message", // desc
            example: "Not found", // example of an error message
          },
          internal_code: {
            type: "string", // data type
            description: "Error internal code", // desc
            example: "Invalid parameters", // example of an error internal code
          },
        },
      },
      addWorkoutPlans: {
        type: "object",
        properties: {
          name: {
            type: "string",
            required: "true",
            description: "Name of the workout plan",
          },
          thumbnail: {
            type: "string",
            format: "binary",
            required: "true",
            description: "Thumbnail of the plan",
          },
          videos: {
            type: "array",
            required: "true",
            description: "ID of Videos to be added to plan",
          },
          programs: {
            type: "array",
            required: "true",
            description: "ID of Programs to be added to plan",
          },
          totalWorkouts: {
            type: "string",
            required: "true",
            description: "Count of workouts in the plan",
          },
          description: {
            type: "string",
            required: "true",
            description: "Description of workout-plan",
          },
          isPublish: {
            type: "string",
            required: "true",
            description: "For publishing immediately send 1 else 0",
          },
        },
      },
      getUuidInput: [
        {
          in: "path",
          name: "uuid",
          required: true,
          schema: {
            type: "string",
          },
          description: "uuid of the Workout plan",
        },
      ],
      getUserInput: [
        {
          in: "query",
          name: "page",
          required: true,
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          required: true,
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "path",
          name: "userUuid",
          required: true,
          schema: {
            type: "string",
          },
          description: "uuid of the user",
        },
      ],
      getPlansFilters: [
        {
          in: "query",
          name: "page",
          required: true,
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          required: true,
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "query",
          name: "search",
          schema: {
            type: "string",
          },
          description: "Enter the Name of Workout Plan",
        },
        {
          in: "query",
          name: "status",
          schema: {
            type: "string",
          },
          description: "Enter the Status of Plan",
        },
        {
          in: "query",
          name: "program",
          schema: {
            type: "string",
          },
          description: "Enter the id of program",
        },
      ],
      getPlansResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: {
                  type: "integer", // data type
                  description: "An id of a workout video", // desc
                },
                uuid: { type: "string" },
                name: { type: "string" },
                description: { type: "string" },
                noOfWorkouts: { type: "integer" },
                thumbNailLocation: { type: "string" },
                status: { type: "string" },
              },
            },
          },
        },
        message: { type: "string" },
      },
      getPlanInput: [
        {
          in: "path",
          name: "planUuid",
          schema: {
            type: "string",
          },
          description: "uuid of the Workout Plan",
        },
      ],
      getPlanUuid: {
        type: "object",
        properties: {
          planUuid: { type: "string" },
        },
      },
      getPlanResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                uuid: { type: "string" },
                name: { type: "string" },
                description: { type: "string" },
                noOfWorkouts: { type: "string" },
                thumbNail: { type: "string" },
                plan_videos: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      id: { type: "string" },
                      uuid: { type: "string" },
                      duration: { type: "string" },
                      workout_id: { type: "integer" },
                      workout_uuid: { type: "string" },
                      savedLocation: { type: "string" },
                      workout_name: { type: "string" },
                      workout_description: { type: "string" },
                      workout_programs: { type: "string" },
                      video_thumbnail: { type: "string" },
                      workout_instructor: { type: "string" },
                    },
                  },
                },
              },
            },
          },
        },
        message: { type: "string" },
      },
    },
  },
};
