module.exports = {
  components: {
    schemas: {
      getAdminInput: [
        {
          in: "path",
          name: "uuid",
          schema: {
            type: "string",
          },
          description: "uuid of the admin",
        },
      ],
      // error model
      Error: {
        type: "object", //data type
        properties: {
          message: {
            type: "string", // data type
            description: "Error message", // desc
            example: "Not found", // example of an error message
          },
          internal_code: {
            type: "string", // data type
            description: "Error internal code", // desc
            example: "Invalid parameters", // example of an error internal code
          },
        },
      },
      getStatusInput: [
        {
          in: "path",
          name: "uuid",
          schema: {
            type: "string",
          },
          description: "uuid of the user",
        },
      ],
      getUserInput: [
        {
          in: "path",
          name: "status",
          schema: {
            type: "string",
          },
          description: "Status of user either 'active' or 'inActive'",
        },
      ],
      getAdminProfileDetails: {
        type: "object",
        properties: {
          firstName: {
            type: "string",
            required: "true",
            description: "Full Name",
          },
          imageLocation: {
            type: "string",
            format: "binary",
            required: "true",
            description: "Profile pictute of admin",
          },
        },
      },
      getInstructorInput: [
        {
          in: "query",
          name: "name",
          schema: {
            type: "string",
          },
          description: "Enter the Name of Instructor",
        },
      ],
      getVerifyOtpResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          message: { type: "string" },
        },
      },
      getOtpVerificationInput: {
        type: "object",
        required: ["otp", "email"],
        properties: {
          otp: {
            type: "string",
            description: "OTP",
          },
          email: {
            type: "string",
            description: "Email",
          },
        },
      },
      getInstructorResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              //type: "object",
              properties: {
                name: { type: "string" },
              },
            },
          },
          message: { type: "string" },
        },
      },
    },
  },
};
