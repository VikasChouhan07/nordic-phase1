const {
  components: {
    schemas: {
      getAdminInput,
      getStatusInput,
      getUserInput,
      getAdminProfileDetails,
      getInstructorResponse,
      getInstructorInput,
      getVerifyOtpResponse,
      getOtpVerificationInput
    },
  },
} = require("./components");
const userPaths = {
  "/api/v1/admins/{uuid}": {
    get: {
      tags: ["Admins"],
      summary: "Get admins",
      description: "Get Stores",
      operationId: "getAdminDetail",
      parameters: getAdminInput,
      responses: {
        201: {
          description: "Success",
        },
        500: {
          description: "Internal server error",
        },
      },
    },
    put: {
      tags: ["Admins"],
      summary: "Update Admin Profile",
      description: "Admin Profile Update",
      operationId: "adminProfileUpdate",
      parameters: getUserInput,
      requestBody: {
        required: true,
        content: {
          "multipart/form-data": {
            schema: getAdminProfileDetails,
          },
        },
      },
      responses: {
        200: {
          description: "Profile Updated Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        204: {
          description: "An error has occured while updating profile!",
        },
        403: {
          description: "Validation errors!",
        },
      },
    },
  },
  "/api/v1/users/{uuid}/status/{status}": {
    patch: {
      tags: ["Admins"],
      summary: "Update User Status",
      description: "Update Users Status",
      operationId: "updateStatus",
      parameters: getStatusInput,
      responses: {
        200: {
          description: "Status Updated Successfully",
        },
        500: {
          description: "Internal Server Error!",
        },
        422: {
          description: "Invalid User Status Code!",
        },
        204: {
          description: "An error has occured while updating Status!",
        },
      },
    },
  },
  "/api/v1/instructors": {
    get: {
      tags: ["Admins"],
      summary: "Get Instructors By Name",
      description: "Get instructors",
      operationId: "getInstructors",
      parameters: getInstructorInput,
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getInstructorResponse,
            },
          },
        },
        500: {
          description: "Internal server error!",
        },
      },
    },
  },
  "/api/v1/verify-otp": {
    post: {
      tags: ["Admins"],
      summary: "Verify OTP",
      description: "Verify OTP",
      operationId: "verifyOtp",
      requestBody: {
        required: true,
        content: {
          "application/json": {
            schema: getOtpVerificationInput,
          },
        },
      },
      responses: {
        200: {
          description: "Success",
          content: {
            // content-type
            "application/json": {
              schema: getVerifyOtpResponse,
            },
          },
        },
        500: {
          description: "Internal Server Error!",
        },
        400: {
          description: "Invalid OTP!",
        },
        401: {
          description: "OTP has been expired!",
        },
      },
    },
  },
};

module.exports = userPaths;
