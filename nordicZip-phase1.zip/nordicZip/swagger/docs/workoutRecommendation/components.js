module.exports = {
  components: {
    schemas: {
      // error model
      Error: {
        type: "object", //data type
        properties: {
          message: {
            type: "string", // data type
            description: "Error message", // desc
            example: "Not found", // example of an error message
          },
          internal_code: {
            type: "string", // data type
            description: "Error internal code", // desc
            example: "Invalid parameters", // example of an error internal code
          },
        },
      },
      recommendationInput: {
        type: "object",
        properties: {
          workoutVideoId: {
            type: "integer",
            required: "true",
            description: "Id of Workout Video",
          },
          fromPublishDate: {
            type: "date",
            required: "true",
            description: "From Publish Date of Workout Recommendation",
          },
          toPublishDate: {
            type: "date",
            required: "true",
            description: "To Publish Date of Workout Recommendation",
          },
          trainingGoals: {
            type: "array",
            required: "true",
            description: "Workout Training Goals",
          },
          status: {
            type: "string",
            required: "true",
            description:
              "Recommendation Status, active: Published, inActive: Unpublished",
          },
        },
      },
      getRecommendationId: [
        {
          in: "path",
          name: "id",
          schema: {
            type: "string",
          },
          description: "id of the Workout Recommendation",
        },
      ],
      getRecommendedInput: [
        {
          in: "path",
          name: "uuid",
          required: true,
          schema: {
            type: "string",
          },
          description: "uuid of the Recommendation",
        },
      ],
      getUserUuid: [
        {
          in: "path",
          name: "userUuid",
          schema: {
            type: "string",
          },
          description: "uuid of the User",
        },
      ],
      getRecommendationFilters: [
        {
          in: "query",
          name: "page",
          schema: {
            type: "integer",
          },
          description: "First page will be 1",
        },
        {
          in: "query",
          name: "pageSize",
          schema: {
            type: "integer",
          },
          description: "Number of records per page",
        },
        {
          in: "query",
          name: "search",
          schema: {
            type: "string",
          },
          description: "Enter the Name of workout or Name of instructor",
        },
        {
          in: "query",
          name: "status",
          schema: {
            type: "string",
          },
          description: "Enter Recommendation Status",
        },
      ],
      getRecommendationsResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: {
                  type: "integer", // data type
                  description: "An id of a workout video", // desc
                },
                uuid: {type: "string"},
                publishedDate: { type: "date" },
                workout_name: { type: "string" },
                instructor_name: { type: "string" },
                status: {type: "string"},
                workout_goals: {
                  type: "array",
                  items: {
                    name: { type: "string" },
                  },
                },
              },
            },
          },
        },
        message: { type: "string" },
      },
      getTodaysRecommendationsResponse: {
        type: "object", // data type
        properties: {
          status: {
            type: "string",
            description: "success | error",
          },
          data: {
            type: "object",
            properties: {
              videoUuid: { type: "string" },
              duration: { type: "string" },
              workout: {
                type: "object",
                properties: {
                  workout_name: {type: "string"},
                  workout_video_details: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        workout_category: {
                          type: "object",
                          properties: {
                            name: { type: "string" },
                          },
                        },
                        workout_sub_category: {
                          type: "object",
                          properties: {
                            name: { type: "string" },
                          },
                        },
                      }
                    },
                  },
                }
              },
              workout_instructor: { type: "string" },
              video_thumbnail: {
                type: "object",
                properties: {
                  savedLocation: { type: "string" },
                },
              },
            },
          },
        },
        message: { type: "string" },
      },
      getPublishRecommendedInput: [
        {
          in: "path",
          name: "uuid",
          schema: {
            type: "string",
          },
          description: "uuid of the Recommendation",
        },
        {
          in: "path",
          name: "publish",
          schema: {
            type: "string",
          },
          description: "Publish Recommendation, active: publish, inActive: unpublish",
        },
      ],
      getRecommendationPublishDate: {
        type: "object",
        properties: {
          fromPublishDate: {
            type: "date",
            required: "true",
            description: "From Publish Date of Workout Recommendation",
          },
          toPublishDate: {
            type: "date",
            required: "true",
            description: "To Publish Date of Workout Recommendation",
          }
        }
      }
    },
  },
};
