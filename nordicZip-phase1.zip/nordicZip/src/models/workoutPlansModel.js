module.exports = (sequelize, type) => {
  const WorkoutPlansModel = sequelize.define(
    "workout_plan",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
        allowNull: false,
      },
      name: {
        type: type.STRING(200),
      },
      description: {
        type: type.STRING(1500),
        allowNull: false,
      },
      noOfWorkouts: {
        type: type.INTEGER,
        allowNull: false,
      },
      thumbNailId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_plans",
    }
  );
  return WorkoutPlansModel;
};
