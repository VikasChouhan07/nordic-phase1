module.exports = (sequelize, type) => {
  const WorkoutFocusesModel = sequelize.define(
    "workout_focuses",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      name: {
        type: type.STRING(100),
      },
      description: {
        type: type.STRING(255),
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      isActive: {
        type: type.TINYINT(1),
        allowNull: false,
        defaultValue: 1,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
      lastUpdatedAt: {
        type: type.DATE,
      },
      lastUpdatedBy: {
        type: type.STRING(50),
      },
    },
    {
      table: "workout_focuses",
    }
  );

  return WorkoutFocusesModel;
};
