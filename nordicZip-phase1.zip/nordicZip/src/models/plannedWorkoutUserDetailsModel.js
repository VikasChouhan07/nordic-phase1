module.exports = (sequelize, type) => {
  const userWorkoutSavedVideoDetails = sequelize.define(
    "planned_workout_user_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutVideoId: {
        type: type.INTEGER,
      },
      workoutSessionDate: {
        type: type.DATE,
      },
      isWorkoutCompleted: {
        type: type.TINYINT(1),
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "planned_workout_user_details",
    }
  );
  return userWorkoutSavedVideoDetails;
};
