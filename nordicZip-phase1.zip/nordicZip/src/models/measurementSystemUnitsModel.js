module.exports = (sequelize, type) => {
  const MeasurementSystemUnitsModel = sequelize.define(
    "measurement_system_unit",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      fullName: {
        type: type.STRING(100),
      },
      shortName: {
        type: type.STRING(100),
      },
      measurementSystemId: {
        type: type.INTEGER,
        allowNull: false,
      },
      physicalParameterId: {
        type: type.INTEGER,
        allowNull: false,
      },
      unitId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.STRING(50),
      },
      lastupdatedAt: {
        type: type.DATE,
      },
      lastupdatedBy: {
        type: type.STRING(100),
      },
      isActive: {
        type: type.INTEGER(4),
        allowNull: false,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "measurement_system_units",
    }
  );

  return MeasurementSystemUnitsModel;
};
