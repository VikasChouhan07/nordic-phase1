module.exports = (sequelize, type) => {
  const WorkoutCategoriesModel = sequelize.define(
    "workout_category",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      name: {
        type: type.STRING(300),
      },
      description: {
        type: type.STRING(500),
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      }
    },
    {
      table: "workout_categories",
    }
  );

  return WorkoutCategoriesModel;
};
