module.exports = (sequelize, type) => {
  const WorkoutPlanDetailsModel = sequelize.define(
    "workout_plan_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      workoutPlanId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutVideoId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_plan_details",
    }
  );
  return WorkoutPlanDetailsModel;
};
