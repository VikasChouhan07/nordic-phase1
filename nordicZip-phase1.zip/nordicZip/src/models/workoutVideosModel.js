module.exports = (sequelize, type) => {
  const WorkoutVideosModel = sequelize.define(
    "workout_video",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
        allowNull: false,
      },
      name: {
        type: type.STRING(100),
      },
      workoutId: {
        type: type.INTEGER,
        allowNull: false,
      },
      isDeleted: {
        type: type.BOOLEAN,
        defaultValue: false
      },
      isDisabled: {
        type: type.BOOLEAN,
        defaultValue: false
      },
      fileName: {
        type: type.STRING(100),
        allowNull: false,
      },
      savedLocation: {
        type: type.STRING(500),
        allowNull: false,
      },
      size: {
        type: type.STRING(20),
        allowNull: false,
      },
      duration: {
        type: type.STRING(20),
        allowNull: false,
      },
      thumbNailId: {
        type: type.INTEGER,
        allowNull: false,
      },
      instructorId: {
        type: type.INTEGER,
        allowNull: false,
      },
      isFeatured: {
        type: type.TINYINT(1),
        allowNull: false,
        defaultValue: 0,
      },
      // isSaved: {
      //   type: type.TINYINT(1),
      //   allowNull: false,
      //   defaultValue: 0,
      // },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_videos",
    }
  );
  return WorkoutVideosModel;
};
