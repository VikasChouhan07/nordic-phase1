module.exports = (sequelize, type) => {
  const WorkoutDurationTypesModel = sequelize.define(
    "workout_duration_type",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      name: {
        type: type.STRING(100),
      },
      description: {
        type: type.STRING(255),
      },
      createdBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      isActive: {
        type: type.TINYINT(1),
        allowNull: false,
        defaultValue: 1,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_duration_types",
    }
  );

  return WorkoutDurationTypesModel;
};
