module.exports = (sequelize, type) => {
  const userWorkoutSavedVideoDetails = sequelize.define(
    "user_workout_saved_video_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutId: {
        type: type.INTEGER,
      },
      workoutVideoId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutCategoryId: {
        type: type.INTEGER,
      },
      workoutSubCategoryId: {
        type: type.INTEGER,
      },
      savedDate: {
        type: type.DATE,
        allowNull: false,
      },
      publishedDate: {
        type: type.DATE,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "user_workout_saved_video_details",
    }
  );
  return userWorkoutSavedVideoDetails;
};
