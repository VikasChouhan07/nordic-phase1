module.exports = (sequelize, type) => {
  const WorkoutVideoDetailsModel = sequelize.define(
    "workout_video_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      workoutId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutSubCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_video_details",
    }
  );

  return WorkoutVideoDetailsModel;
};
