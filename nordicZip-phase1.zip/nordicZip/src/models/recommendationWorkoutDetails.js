module.exports = (sequelize, type) => {
  const recommendationWorkoutDetail = sequelize.define(
    "recommendation_workout_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      recommendationId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutSubCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "recommendation_workout_details",
    }
  );

  return recommendationWorkoutDetail;
};
