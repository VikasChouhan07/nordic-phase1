module.exports = (sequelize, type) => {
  const WorkoutPlanCategoriesModel = sequelize.define(
    "workout_plan_category",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      workoutPlanId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutSubCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_plan_categories",
    }
  );

  return WorkoutPlanCategoriesModel;
};
