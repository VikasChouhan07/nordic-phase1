module.exports = (sequelize, type) => {
  const Units = sequelize.define(
    "unit",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      fullName: {
        type: type.STRING(100),
        allowNull: false,
      },
      shortName: {
        type: type.STRING(100),
        allowNull: false,
      },
      createdAt: {
        type: type.DATE,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedAt: {
        type: type.DATE,
      },
      updatedBy: {
        type: type.STRING(100),
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "units",
    }
  );

  return Units;
};
