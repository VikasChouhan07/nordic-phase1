module.exports = (sequelize, type) => {
  const queryTypesModel = sequelize.define(
    "query_type",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.INTEGER,
        allowNull: false,
      },
      name: {
        type: type.STRING(100),
        allowNull: false,
      },
      description: {
        type: type.STRING(300),
        allowNull: false,
      },
      createdAt: {
        type: type.DATE,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedAt: {
        type: type.DATE,
      },
      updatedBy: {
        type: type.STRING(100),
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "query_types",
    }
  );

  return queryTypesModel;
};
