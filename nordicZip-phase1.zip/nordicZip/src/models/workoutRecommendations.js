module.exports = (sequelize, type) => {
  const workoutRecommendations = sequelize.define(
    "workout_recommendation",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      workoutId: {
        type: type.INTEGER,
      },
      workoutVideoId: {
        type: type.INTEGER,
        allowNull: false,
      },
      fromPublishDate: {
        type: type.DATE,
      },
      toPublishDate: {
        type: type.DATE,
      },
      isDeleted: {
        type: type.BOOLEAN,
        defaultValue: false
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_recommendations",
    }
  );

  return workoutRecommendations;
};
