module.exports = (sequelize, type) => {
  const WorkoutPlanThumbnailsModel = sequelize.define(
    "workout_plan_thumbnail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      name: {
        type: type.STRING(100),
      },
      serverAddress: {
        type: type.STRING(100),
      },
      region: {
        type: type.STRING(100),
      },
      filename: {
        type: type.STRING(100),
      },
      savedLocation: {
        type: type.STRING(1000),
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_plan_thumbnails",
    }
  );

  return WorkoutPlanThumbnailsModel;
};
