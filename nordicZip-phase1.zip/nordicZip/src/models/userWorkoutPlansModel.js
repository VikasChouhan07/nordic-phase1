module.exports = (sequelize, type) => {
  const userWorkoutPlansModel = sequelize.define(
    "user_workout_plan",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
        allowNull: false,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      type: {
        type: type.TINYINT(1),
        allowNull: false,
      },
      planOrVideoId: {
        type: type.INTEGER,
      },
      videoSavedDate: {
        type: type.DATE,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "user_workout_plans",
    }
  );
  return userWorkoutPlansModel;
};
