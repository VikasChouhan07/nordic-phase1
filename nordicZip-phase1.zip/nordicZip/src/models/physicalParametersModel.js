module.exports = (sequelize, type) => {
  const PhysicalParameters = sequelize.define(
    "physical_parameter",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      uuid: {
        type: type.STRING(100),
      },
      name: {
        type: type.STRING(100),
        allowNull: false,
      },
      description: {
        type: type.STRING(1000),
        allowNull: false,
      },
      createdAt: {
        type: type.DATE,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedAt: {
        type: type.DATE,
      },
      updatedBy: {
        type: type.STRING(100),
      },
      isActive: {
        type: type.TINYINT(1),
        allowNull: false,
      },
      lastUpdatedAt: {
        type: type.DATE,
      },
      lastUpdatedBy: {
        type: type.STRING(50),
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "physical_parameters",
    }
  );

  return PhysicalParameters;
};
