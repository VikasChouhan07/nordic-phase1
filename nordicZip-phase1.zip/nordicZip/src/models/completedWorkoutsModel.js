module.exports = (sequelize, type) => {
  const completedWorkoutsModel = sequelize.define(
    "completed_workout",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutVideoId: {
        type: type.INTEGER,
        allowNull: false
      },
      completionDate: {
        type: type.DATE,
        allowNull: false
      },
      isCompleted: {
        type: type.TINYINT(1)
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "completed_workouts",
    }
  );
  return completedWorkoutsModel;
};
