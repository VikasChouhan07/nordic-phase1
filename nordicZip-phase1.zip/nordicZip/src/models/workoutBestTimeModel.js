module.exports = (sequelize, type) => {
  const workoutBestTimeModel = sequelize.define(
    "workout_best_time",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: true,
      },
      distanceCovered: {
        type: type.INTEGER,
        allowNull: true,
      },
      bestTime: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdBy: {
        type: type.STRING(50),
      },
      updatedBy: {
        type: type.INTEGER,
        allowNull: true,
      },
      createdAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      updatedAt: {
        type: type.DATE,
        defaultValue: sequelize.NOW,
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "workout_best_times",
    }
  );

  return workoutBestTimeModel;
};
