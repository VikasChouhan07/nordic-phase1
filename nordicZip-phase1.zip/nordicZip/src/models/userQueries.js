module.exports = (sequelize, type) => {
  const userQueryModel = sequelize.define(
    "user_query",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      queryTypeId: {
        type: type.INTEGER,
        allowNull: false,
      },
      subject: {
        type: type.STRING(300),
        allowNull: false,
      },
      queryDescription: {
        type: type.STRING(1500),
        allowNull: false,
      },
      queryDate: {
        type: type.DATE,
        allowNull: false,
      },
      queryStatusDescription: {
        type: type.STRING(1000),
      },
      isResolved: {
        type: type.TINYINT(1),
      },
      queryResolvedDate: {
        type: type.DATE,
      },
      createdAt: {
        type: type.DATE,
        allowNull: false,
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedAt: {
        type: type.DATE,
      },
      updatedBy: {
        type: type.STRING(100),
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
    },
    {
      table: "user_queries",
    }
  );

  return userQueryModel;
};
