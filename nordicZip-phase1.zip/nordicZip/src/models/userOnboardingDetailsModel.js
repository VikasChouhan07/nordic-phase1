module.exports = (sequelize, type) => {
  const UserOnboardingDetailsModel = sequelize.define(
    "user_onboarding_detail",
    {
      id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      userId: {
        type: type.INTEGER,
        allowNull: false,
      },
      measurementId: {
        type: type.INTEGER,
        allowNull: false,
      },
      goalCategoryId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutDurationId: {
        type: type.INTEGER,
        allowNull: false,
      },
      workoutFrequencyId: {
        type: type.STRING(100),
        allowNull: false,
      },
      workoutFrequency: {
        type: type.INTEGER,
        allowNull: false,
      },
      onboardingDate: {
        type: type.DATE,
        allowNull: false,
      },
      height: {
        type: type.DECIMAL(10, 2),
      },
      weight: {
        type: type.DECIMAL(10, 2),
      },
      createdBy: {
        type: type.STRING(100),
      },
      updatedBy: {
        type: type.STRING(100),
      },
      statusId: {
        type: type.INTEGER,
        allowNull: false,
      },
      isPlanned: {
        type: type.INTEGER,
        allowNull: false,
        default: 0,
      },
    },
    {
      table: "user_onboarding_details",
    }
  );

  return UserOnboardingDetailsModel;
};
