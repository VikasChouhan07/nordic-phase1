let jwt = require("jsonwebtoken");
const {
  response: {
    statuses: { error },
    create,
  },
} = require("./helpers/common");
const { translate } = require("./helpers/multilingual");
const { getActiveStatuses, statuses } = require("./helpers/sequelize");
const { userTypes } = require("./helpers/users");
const model = require("./models/index");
const usersTypesModel = model.user_type;
const userModel = model.user;
const checkToken = async (req, res, next) => {
  let token = req.headers["authorization"]; // Express headers are auto converted to lowercase
  const translateObj = translate(req.headers.lang);
  if (token) {
    if (token.startsWith("Bearer ")) {
      // Remove Bearer from string
      token = token.slice(7, token.length);
    }
    const activeStatuses = await getActiveStatuses();
    const { id: activeStatus } = activeStatuses?.find(
      (rec) => rec.name === statuses.active
    );
    jwt.verify(
      token,
      process.env.JWT_ACCESS_TOKEN_SECRET,
      async (err, decoded) => {
        if (err) {
          return create(res, error, {}, translateObj.__("INVALID_TOKEN"), 401);
        } else {
          req.decoded = decoded;
          const userToVerify = await userModel.findOne({
            where: { id: req.decoded.id },
          });
          if (parseInt(userToVerify.statusId) !== parseInt(activeStatus)) {
            return create(
              res,
              error,
              {},
              translateObj.__("ACCOUNT_DISABLED"),
              401
            );
          }
          next();
        }
      }
    );
  } else {
    return create(res, error, {}, translateObj.__("NO_TOKEN_SUPPLIED"), 401);
  }
};

const checkAdminCredentials = async (req, res, next) => {
  const translateObj = translate(req.headers.lang);
  const userData = await userModel.findOne({
    where: { id: req.decoded.id },
  });
  const adminData = await usersTypesModel.findOne({
    where: { name: userTypes.admin },
  });
  if (userData.userTypeId != adminData.id) {
    return create(res, error, {}, translateObj.__("INVALID_CREDENTIALS"), 401);
  }
  next();
};

const createAccessToken = (data) => {
  return jwt.sign(
    {
      id: data.id,
      uuid: data.uuid,
      email: data.email,
    },
    process.env.JWT_ACCESS_TOKEN_SECRET,
    {
      expiresIn: process.env.JWT_EXPIRES_IN,
    }
  );
};

const createRefreshToken = (data) => {
  return jwt.sign(
    {
      id: data.id,
      uuid: data.uuid,
      email: data.email,
    },
    process.env.JWT_REFRESH_TOKEN_SECRET
  );
};

module.exports = {
  checkToken,
  createAccessToken,
  createRefreshToken,
  checkAdminCredentials,
};
