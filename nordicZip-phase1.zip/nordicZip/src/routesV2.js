const router = require("express").Router();
const { checkToken, checkAdminCredentials } = require("./middleware");
const moment = require("moment");
const usersControllerV2 = require("./controllers/v2/usersController");
const adminControllerV2 = require("./controllers/v2/adminController");
const authControllerV2 = require("./controllers/v2/authController");
const workoutsControllerV2 = require("./controllers/v2/workoutsController");
const reportsAndFaqController = require("./controllers/v2/reportsAndFaqController");
const recommendationControllerV2 = require("./controllers/v2/recommendationsController");
const workoutPlansControllerV2 = require("./controllers/v2/workoutPlansController");
/*---------------------------------------------------------------------------------
 Define All the Routes Below. The routes will follow REST API standards strictly.
 ---------------------------------------------------------------------------------*/
router.get("/", (req, res) => {
  const port = process.env.PORT || 3001;
  res.send(
    `Nordic Strong Express Application is running on this Server. Server Datetime: ${moment().format(
      "MMMM Do YYYY, h:mm:ss a z"
    )} <br><br> Swagger is running on <a href="http://localhost:${port}/api-docs-v2">http://localhost:${port}/api-docs</a>`
  );
});

// Authentication Routes
router.post("/v2/login", authControllerV2.login);
router.post("/v2/logout", checkToken, authControllerV2.logout);
router.post("/v2/refresh-token", authControllerV2.getToken);
router.get("/v2/otp/:email", authControllerV2.getOtp);
router.post("/v2/signup", authControllerV2.signup);

router.post(
  "/v2/onboarding-details",
  checkToken,
  authControllerV2.addOnboardingDetails
);

router.post("/v2/users", checkToken, usersControllerV2.addUser);
router.get("/v2/users/:uuid", checkToken, usersControllerV2.getUser);
router.get("/v2/programs", usersControllerV2.getPrograms);
router.get("/v2/muscle-groups", usersControllerV2.getMuscleGroups);
router.get("/v2/training-goals", usersControllerV2.getTrainingGoals);
router.get("/v2/focuses", usersControllerV2.getFocuses);
router.get("/v2/measurement-systems", usersControllerV2.getMeasurementSystems);
router.get(
  "/v2/workout-duration-types",
  usersControllerV2.getWorkoutDurationTypes
);
router.get(
  "/v2/workout-frequency-types",
  usersControllerV2.getWorkoutFrequencyTypes
);

router.put("/v2/users/:uuid/reset-password", authControllerV2.changePassword);
router.post(
  "/v2/users/:uuid/change-password",
  checkToken,
  authControllerV2.changePassword
);
router.post("/v2/verify-otp", authControllerV2.verifyOtp);
router.post("/v2/otp-verify", authControllerV2.appOtpVerify);

// Admin Controller Routes
router.get(
  "/v2/otp/:email/type/new-email",
  checkToken,
  authControllerV2.getNewEmailOtp
);
router.get(
  "/v2/admins/:uuid",
  checkToken,
  checkAdminCredentials,
  adminControllerV2.getAdmin
);

router.get("/v2/users", checkToken, adminControllerV2.getUsers);
router.put(
  "/v2/admins/:uuid",
  checkToken,
  checkAdminCredentials,
  adminControllerV2.update
);
router.put("/v2/users/:uuid", checkToken, usersControllerV2.update);
router.patch(
  "/v2/users/:uuid/status/:status",
  checkToken,
  checkAdminCredentials,
  adminControllerV2.updateStatus
);
router.patch(
  "/v2/users/:uuid/email",
  checkToken,
  checkAdminCredentials,
  adminControllerV2.updateEmail
);
router.post(
  "/v2/workout-videos",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV2.addWorkoutVideo
);

router.get(
  "/v2/workout-videos",
  checkToken,
  workoutsControllerV2.getWorkoutVideos
);
router.get(
  "/v2/workout-videos/category/:type/sub-category-id/:id",
  checkToken,
  workoutsControllerV2.getWorkoutVideosCategory
);
router.get(
  "/v2/workout-videos/:uuid",
  checkToken,
  workoutsControllerV2.getWorkout
);
router.put(
  "/v2/workout-videos/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV2.updateWorkoutVideo
);

router.get(
  "/v2/workout-videos/user/:userUuid",
  checkToken,
  workoutsControllerV2.getSavedWorkout
);

router.post(
  "/v2/planned-workouts",
  checkToken,
  workoutsControllerV2.scheduleWorkout
);

router.delete(
  "/v2/workout-videos",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV2.deleteWorkouts
);

router.patch(
  "/v2/workout-videos/featured/:featured",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV2.featureWorkouts
);

router.patch(
  "/v2/workout-videos/:uuid/status/:status",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV2.updateWorkoutStatus
);

router.post(
  "/v2/workout-videos/user/:uuid",
  checkToken,
  workoutsControllerV2.saveWorkoutForUser
);

router.get(
  "/v2/completed-workouts",
  checkToken,
  workoutsControllerV2.getWorkoutsHistory
);

router.post(
  "/v2/completed-workouts",
  checkToken,
  workoutsControllerV2.markWorkoutCompleted
);

router.get("/v2/instructors", adminControllerV2.getInstructors);
router.get(
  "/v2/recommendation/:uuid",
  checkToken,
  recommendationControllerV2.getRecommendationOfAdmin
);

// Recommendation Controller Routes
router.post(
  "/v2/recommendations",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV2.addRecommendation
);
router.put(
  "/v2/recommendations/:id",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV2.editRecommendation
);
router.get(
  "/v2/recommendations",
  checkToken,
  recommendationControllerV2.getRecommendation
);
router.delete(
  "/v2/recommendation/:uuid",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV2.deleteRecommendation
);

router.patch(
  "/v2/recommendations/:uuid/publish/:publish",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV2.publishRecommendation
);

router.get(
  "/v2/recommendations/user/:userUuid",
  checkToken,
  recommendationControllerV2.getTodaysRecommendation
);

// Report and FAQ Controller Routes
router.get("/v2/faqs", checkToken, reportsAndFaqController.getFaqs);
router.get("/v2/faqs/:id", checkToken, reportsAndFaqController.getFaq);
router.delete(
  "/v2/faqs/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.deleteFaq
);
router.put(
  "/v2/faqs/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.editFaq
);
router.post(
  "/v2/faqs",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.postFaq
);
router.post("/v2/queries", checkToken, reportsAndFaqController.postIssue);
router.get(
  "/v2/queries/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.getQuery
);
router.delete(
  "/v2/queries/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.deleteIssue
);
router.patch(
  "/v2/queries/:id/resolved/:resolved",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.resolveIssue
);
router.get(
  "/v2/queries",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.getAllQueries
);

//Workout Plans Controller Routes
router.post(
  "/v2/workout-plans",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV2.addWorkoutPlan
);

router.get(
  "/v2/workout-plans",
  checkToken,
  workoutPlansControllerV2.getAllWorkoutPlans
);

router.delete(
  "/v2/workout-plans/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV2.deleteWorkoutPlan
);

router.put(
  "/v2/workout-plans/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV2.editWorkoutPlan
);

router.get(
  "/v2/workout-plans/plan/:planUuid",
  checkToken,
  workoutPlansControllerV2.getWorkoutPlan
);

router.post(
  "/v2/saved-workout-plans",
  checkToken,
  workoutPlansControllerV2.saveWorkoutPlan
);

router.get(
  "/v2/planned-workouts/user/:userUuid",
  checkToken,
  workoutsControllerV2.getScheduledWorkouts
);

router.post(
  "/v2/user/workout-best-time",
  checkToken,
  workoutsControllerV2.saveUsersBestTime
);

module.exports = router;
