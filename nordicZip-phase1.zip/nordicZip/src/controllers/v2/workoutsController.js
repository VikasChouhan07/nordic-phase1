const model = require("../../models/index");
const { translate } = require("../../helpers/multilingual");
const { handleError } = require("../../helpers/errorHandling");
const {
  response: {
    statuses: { success: successStatus, error: errorStatus },
    create: createResponse,
  },
} = require("../../helpers/common");
const { v4: uuidv4 } = require("uuid");
const { validate } = require("../../helpers/validator");
const { uploadFilesToS3, getSignedUrlFromS3 } = require("../../helpers/aws");
const {
  getActiveStatuses,
  statuses,
  createSortBy,
  addFiltersToWhereClause,
} = require("../../helpers/sequelize");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const statusModel = model.status;
const usersTypesModel = model.user_type;
const {
  flattenWorkouts,
  flattenSavedWorkouts,
} = require("../../helpers/workouts");
const { dateFormat1, dateFormat3 } = require("../../helpers/dates");
const moment = require("moment");
const { userTypes, savedWorkoutType } = require("../../helpers/users");
const userModel = model.user;
const workoutsModel = model.workout;
const workoutVideosModel = model.workout_video;
const videoThumbnailsModel = model.video_thumbnail;
const workoutInstructorsModel = model.workout_instructor;
const workoutVideoDetailsModel = model.workout_video_detail;
const workoutCategoriesModel = model.workout_category;
const workoutSubCategoriesModel = model.workout_sub_category;
const usersOnboardingDetailsModel = model.user_onboarding_detail;
const workoutRecommendations = model.workout_recommendation;
const workoutPlanDetailsModel = model.workout_plan_detail;
const workoutPlansModel = model.workout_plan;
const plannedWorkoutUserDetailsModel = model.planned_workout_user_detail;
const completedWorkoutsModel = model.completed_workout;
const userWorkoutPlansModel = model.user_workout_plan;
const workoutPlanCategoriesModel = model.workout_plan_category;
const workoutPlanThumbnailsModel = model.workout_plan_thumbnail;
const workoutBestTimeModel = model.workout_best_time;

//associating workoutsModel with workoutVideoDetailsModel
workoutsModel.hasMany(workoutVideoDetailsModel);
workoutVideoDetailsModel.belongsTo(workoutsModel);

//associating workoutsModel with workoutVideosModel
workoutsModel.hasMany(workoutVideosModel, {
  //foreignKey: "id",
});
workoutVideosModel.belongsTo(workoutsModel, {
  foreignKey: "workoutId",
});

statusModel.hasOne(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(statusModel, {
  foreignKey: "statusId",
});

//associating videoThumbnailsModel with workoutVideosModel
videoThumbnailsModel.hasOne(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(videoThumbnailsModel, {
  foreignKey: "thumbNailId",
});

//associating workoutInstructorsModel with workoutVideosModel
workoutInstructorsModel.hasMany(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(workoutInstructorsModel, {
  foreignKey: "instructorId",
});

//associating workoutCategoriesModel with workoutVideoDetailsModel
workoutCategoriesModel.hasMany(workoutVideoDetailsModel, {
  foreignKey: "id",
});
workoutVideoDetailsModel.belongsTo(workoutCategoriesModel, {
  foreignKey: "workoutCategoryId",
});

//associating workoutSubCategoriesModel with workoutVideoDetailsModel
workoutSubCategoriesModel.hasMany(workoutVideoDetailsModel, {
  //foreignKey: "id",
});
workoutVideoDetailsModel.belongsTo(workoutSubCategoriesModel, {
  foreignKey: "workoutSubCategoryId",
});

workoutVideosModel.hasMany(completedWorkoutsModel, {
  foreignKey: "id",
});

completedWorkoutsModel.belongsTo(workoutVideosModel, {
  foreignKey: "workoutVideoId",
});

workoutVideosModel.hasOne(plannedWorkoutUserDetailsModel, {
  foreignKey: "workoutVideoId",
});

plannedWorkoutUserDetailsModel.belongsTo(workoutVideosModel, {
  foreignKey: "id",
});

workoutVideosModel.hasMany(userWorkoutPlansModel, {
  foreignKey: "planOrVideoId",
});

userWorkoutPlansModel.belongsTo(workoutVideosModel, {
  foreignKey: "id",
});

workoutVideosModel.hasMany(completedWorkoutsModel, {
  foreignKey: "workoutVideoId",
});

completedWorkoutsModel.belongsTo(workoutVideosModel, {
  foreignKey: "id",
});

module.exports = {
  addWorkoutVideo: async (req, res) => {
    try {
      const validations = {
        workoutName: "required|maxLength:200",
        programs: "required",
        muscleGroups: "required",
        focus: "required",
        instructorName: "required",
        trainingGoal: "required",
        description: "required|maxLength:1500",
        duration: "required",
        thumbnail: "required",
        video: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        { ...req.body, ...req.files },
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { workoutName, instructorName, description, duration },
      } = req;

      const programs = req.body.programs.split(",");
      const muscleGroups = req.body.muscleGroups.split(",");
      const focus = req.body.focus.split(",");
      const trainingGoal = req.body.trainingGoal.split(",");
      uploadFilesToS3(
        [req.files.video],
        process.env.AWS_S3_WORKOUT_VIDEOS_FOLDER_NAME
      ).then(async (videoData) => {
        const imageData = await uploadFilesToS3(
          [req.files.thumbnail],
          process.env.AWS_S3_WORKOUT_VIDEO_THUMBNAILS_FOLDER_NAME
        );
        const activeStatuses = await getActiveStatuses();
        const activeStatus = activeStatuses?.find(
          (rec) => rec.name === statuses.active
        ).id;
        await model.sequelize.transaction().then(async (t) => {
          try {
            const thumbnailCreatedData = await videoThumbnailsModel.create(
              {
                uuid: uuidv4(),
                name: req.files.thumbnail.name,
                filename: req.files.thumbnail.name,
                savedLocation: imageData.Key,
                createdBy: req.decoded.id,
                statusId: activeStatus,
              },
              { transaction: t }
            );
            const workoutDataCreated = await workoutsModel.create(
              {
                uuid: uuidv4(),
                name: workoutName,
                description: description,
                createdBy: req.decoded.id,
                statusId: activeStatus,
              },
              { transaction: t }
            );
            const [instructorsData] =
              await workoutInstructorsModel.findOrCreate({
                where: {
                  name: instructorName,
                },
                defaults: {
                  uuid: uuidv4(),
                  name: instructorName,
                  statusId: activeStatus,
                  createdBy: req.decoded.id,
                },
                transaction: t,
              });
            await workoutVideosModel.create(
              {
                uuid: uuidv4(),
                name: workoutName,
                fileName: req.files.video.name,
                savedLocation: videoData.Key,
                size: req.files.video.size,
                duration: duration,
                workoutId: workoutDataCreated.id,
                thumbNailId: thumbnailCreatedData.id,
                instructorId: instructorsData.id,
                statusId: activeStatus,
                createdBy: req.decoded.id,
                isDeleted: 0,
                isDisabled: 0,
              },
              { transaction: t }
            );
            const musclesData = muscleGroups.map((muscle) => {
              return {
                workoutId: workoutDataCreated.id,
                workoutCategoryId: 2,
                workoutSubCategoryId: muscle,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const focusesData = focus.map((focus) => {
              return {
                workoutId: workoutDataCreated.id,
                workoutCategoryId: 3,
                workoutSubCategoryId: focus,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const programsData = programs.map((program) => {
              return {
                workoutId: workoutDataCreated.id,
                workoutCategoryId: 1,
                workoutSubCategoryId: program,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const goalsData = trainingGoal.map((goal) => {
              return {
                workoutId: workoutDataCreated.id,
                workoutCategoryId: 4,
                workoutSubCategoryId: goal,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const dataToInsert = [
              ...focusesData,
              ...musclesData,
              ...goalsData,
              ...programsData,
            ];
            await workoutVideoDetailsModel.bulkCreate(dataToInsert, {
              transaction: t,
            });
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });
      });
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("WORKOUT_UPLOADING"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getWorkoutVideos: async (req, res) => {
    try {
      const page = req.query.page ? parseInt(req.query.page) : 0;
      // Call Translate
      const translateObj = translate(req.headers.lang);
      const pageSize = parseInt(req.query.pageSize);
      const sortByDefault = ["createdAt", "DESC"];
      const {
        sortBy: sortByParams,
        search: filterString,
        status: filterStatus,
        fromDate,
        toDate,
        isFeatured,
      } = req.query;
      let whereClause = {};

      const sortBy = sortByParams?.length
        ? createSortBy(sortByParams)
        : sortByDefault;

      const searchByColumns = ["workout_instructor.name", "workout.name"];
      const dateFilterColumn = "registrationDate";
      if (filterString || filterStatus || fromDate || toDate) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          filterStatus,
          fromDate,
          toDate,
          dateFilterColumn,
        };
        whereClause = addFiltersToWhereClause(filters);
      }

      const userData = await userModel.findOne({
        where: { id: req.decoded.id },
      });

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const adminData = await usersTypesModel.findOne({
        where: { name: userTypes.admin },
      });

      if (userData.userTypeId != adminData.id) {
        whereClause.statusId = activeStatus;
      }

      //get list of only featured workouts
      if (isFeatured) whereClause.isFeatured = parseInt(isFeatured);

      whereClause.isDeleted = 0;

      let workoutGetIds = {
        distinct: true,
        attributes: ["id"],
        include: [
          {
            model: workoutsModel,
            attributes: ["id", "uuid", "name", "description"],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
          },
        ],
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
      };

      let workoutGetQuery = {
        //  subQuery: false,
        distinct: true,
        attributes: [
          "id",
          "savedLocation",
          "size",
          "duration",
          "createdAt",
          "isDeleted",
          "isFeatured",
          "uuid",
        ],
        include: [
          {
            model: workoutsModel,
            attributes: ["id", "uuid", "name", "description"],
            //   required: true,
            include: [
              {
                model: workoutVideoDetailsModel,
                attributes: ["id"],
                // required: true,
                include: [
                  {
                    model: workoutCategoriesModel,
                    attributes: ["name"],
                    //  required: true,
                  },
                  {
                    model: workoutSubCategoriesModel,
                    attributes: ["name"],
                    // required: true,
                  },
                ],
              },
            ],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
            // required: true,
          },
          {
            model: videoThumbnailsModel,
            attributes: ["filename", "savedLocation"],
            // required: true,
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.video },
            required: false,
          },
        ],
        where: whereClause,
        order: [sortBy],
      };
      let dataFind;
      if (req.query.search) {
        dataFind = await workoutVideosModel.findAndCountAll(workoutGetIds);
        const ids = dataFind.rows.map((obj) => {
          return obj.id;
        });
        workoutGetQuery.where = { id: { [Op.in]: ids } };
      }

      if (page != 0 && !req.query.search) {
        workoutGetQuery.limit = pageSize;
        workoutGetQuery.offset = (page - 1) * pageSize;
      }
      const { count, rows } = await workoutVideosModel.findAndCountAll(
        workoutGetQuery
      );
      const countData = dataFind ? dataFind.count : count;

      if (rows) {
        const flatData = flattenWorkouts(rows, false);
        return createResponse(
          res,
          successStatus,
          { records: flatData, totalCount: countData, page, pageSize },
          translateObj.__("USERS_FETCHED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("USERS_NOT_AVAILABLE"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getWorkout: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const workoutData = await workoutVideosModel.findOne({
        where: {
          uuid: req.params.uuid,
        },
        attributes: [
          "id",
          "uuid",
          "savedLocation",
          "size",
          "duration",
          "createdAt",
        ],
        include: [
          {
            model: workoutsModel,
            attributes: ["id", "uuid", "name", "description"],
            include: [
              {
                model: workoutVideoDetailsModel,
                attributes: ["id"],
                include: [
                  {
                    model: workoutCategoriesModel,
                    attributes: ["name"],
                  },
                  {
                    model: workoutSubCategoriesModel,
                    attributes: ["id", "name"],
                  },
                ],
              },
            ],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
          },
          {
            model: videoThumbnailsModel,
            attributes: ["filename", "savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.video },
            required: false,
          },
          {
            model: plannedWorkoutUserDetailsModel,
            attributes: ["id", "workoutSessionDate"],
            where: { userId: req.decoded.id },
            required: false,
          },
          {
            model: completedWorkoutsModel,
            attributes: ["id"],
            where: { userId: req.decoded.id },
            required: false,
          },
        ],
      });

      const userData = await userModel.findOne({
        where: { id: req.decoded.id },
      });

      const adminData = await usersTypesModel.findOne({
        where: { name: userTypes.admin },
      });

      let getCategoryId = true;

      //send subcategory names if user logged in else send subcategory id
      if (userData.userTypeId != adminData.id) getCategoryId = false;

      if (workoutData) {
        const flatData = flattenWorkouts([workoutData], getCategoryId);
        return createResponse(
          res,
          successStatus,
          flatData[0],
          translateObj.__("WORKOUT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_NOT_FOUND"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },

  deleteWorkouts: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        body: { uuids },
      } = req;
      const videoUuids = uuids.split(",");

      if (!uuids?.length) {
        throw new handleError(translateObj.__("UUIDS_REQUIRED"), 400, {});
      }

      const activeStatuses = await getActiveStatuses();
      const deleteStatusId = activeStatuses?.find(
        (rec) => rec.name === statuses.deleted
      ).id;

      const workoutDeleteData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            await workoutVideosModel.update(
              { isDeleted: 1 },
              {
                where: {
                  uuid: videoUuids,
                },
                transaction: t,
              }
            );
            const videoData = await workoutVideosModel.findOne({
              where: { uuid: videoUuids },
            });

            await workoutVideoDetailsModel.update(
              { statusId: deleteStatusId },
              {
                where: {
                  workoutId: videoData.workoutId,
                },
                transaction: t,
              }
            );

            await workoutRecommendations.update(
              { isDeleted: 1 },
              {
                where: {
                  workoutVideoId: videoData.id,
                },
                transaction: t,
              }
            );
            await userWorkoutPlansModel.update(
              { statusId: deleteStatusId },
              {
                where: {
                  planOrVideoId: videoData.id,
                  type: savedWorkoutType.video,
                },
                transaction: t,
              }
            );

            await workoutPlanDetailsModel.update(
              { statusId: deleteStatusId },
              {
                where: {
                  workoutVideoId: videoData.id,
                },
                transaction: t,
              }
            );

            let planIds = await workoutPlanDetailsModel.findAll({
              attributes: ["workoutPlanId"],
              where: {
                workoutVideoId: videoData.id,
              },
              raw: true,
            });

            planIds = planIds.map((data) => {
              return data.workoutPlanId;
            });

            await workoutPlansModel.decrement("noOfWorkouts", {
              by: 1,
              where: {
                id: { [Op.in]: planIds },
              },
            });

            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (workoutDeleteData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("VIDEO_DELETED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("DELETE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },

  getWorkoutVideosCategory: async (req, res) => {
    try {
      const validations = {
        page: "required",
        pageSize: "required",
      };
      // Call Translate
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }
      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const {
        params: { type, id },
      } = req;

      let whereClause = {};
      whereClause.statusId = activeStatus;

      if (type === "userMightLike") {
        const userGoal = await usersOnboardingDetailsModel.findOne({
          where: { userId: req.decoded.id },
          attributes: ["goalCategoryId"],
        });
        whereClause.workoutSubCategoryId = userGoal.goalCategoryId;
      } else if (id) {
        whereClause.workoutSubCategoryId = id;
      }
      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);
      const sortByDefault = ["createdAt", "DESC"];
      const sortBy = sortByDefault;

      const { count, rows } = await workoutVideoDetailsModel.findAndCountAll({
        attributes: ["workoutId"],
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
      });
      const workoutIds = rows.map((obj) => obj.workoutId);
      const workouts = await workoutVideosModel.findAll({
        subQuery: false,
        distinct: true,
        where: {
          workoutId: { [Op.in]: workoutIds },
        },
        attributes: [
          "id",
          "uuid",
          "savedLocation",
          "size",
          "duration",
          "createdAt",
          "isDeleted",
          "isFeatured",
        ],
        include: [
          {
            model: workoutsModel,
            attributes: ["id", "uuid", "name", "description"],
            include: [
              {
                model: workoutVideoDetailsModel,
                attributes: ["id", "workoutSubCategoryId"],
                include: [
                  {
                    model: workoutCategoriesModel,
                    attributes: ["name"],
                  },
                  {
                    model: workoutSubCategoriesModel,
                    attributes: ["name"],
                  },
                ],
              },
            ],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
          },
          {
            model: videoThumbnailsModel,
            attributes: ["filename", "savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.video },
            required: false,
          },
        ],
        order: [sortBy],
      });

      if (rows) {
        const flatData = flattenWorkouts(workouts, false);
        return createResponse(
          res,
          successStatus,
          { records: flatData, totalCount: count, page, pageSize },
          translateObj.__("WORKOUT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  featureWorkouts: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { featured },
        body: { uuids },
      } = req;
      const videoUuids = uuids.split(",");

      const message = parseInt(featured)
        ? "VIDEO_FEATURED"
        : "VIDEO_UNFEATURED";

      if (!uuids?.length) {
        throw new handleError(
          translateObj.__("UUIDS_REQUIRED_TO_FEATURE"),
          400,
          {}
        );
      }
      const workoutFeatureData = await workoutVideosModel.update(
        { isFeatured: featured },
        {
          where: {
            uuid: videoUuids,
          },
        }
      );
      if (workoutFeatureData[0]) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__(message),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("FEATURE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  updateWorkoutVideo: async (req, res) => {
    try {
      const validations = {
        workoutName: "required",
        programs: "required",
        muscleGroups: "required",
        focus: "required",
        instructorName: "required",
        trainingGoal: "required",
        description: "required",
        duration: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        { ...req.body },
        validations
      );

      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { workoutName, instructorName, description, duration },
      } = req;

      const programs = req.body.programs.split(",");
      const muscleGroups = req.body.muscleGroups.split(",");
      const focus = req.body.focus.split(",");
      const trainingGoal = req.body.trainingGoal.split(",");

      let imageData;
      if (req.files && req.files.thumbnail) {
        imageData = await uploadFilesToS3(
          [req.files.thumbnail],
          process.env.AWS_S3_WORKOUT_VIDEO_THUMBNAILS_FOLDER_NAME
        );

        if (!imageData)
          throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      }

      let videoData;
      if (req.files && req.files.video) {
        videoData = await uploadFilesToS3(
          [req.files.video],
          process.env.AWS_S3_WORKOUT_VIDEOS_FOLDER_NAME
        );

        if (!videoData)
          throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const workoutsUpdateData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            const workoutId = await workoutsModel.findOne(
              {
                where: { uuid: req.params.uuid },
                attributes: ["id"],
              },
              { transaction: t }
            );

            await workoutsModel.update(
              {
                name: workoutName,
                description: description,
                statusId: activeStatus,
              },
              {
                where: {
                  uuid: {
                    [Op.eq]: req.params.uuid,
                  },
                },
              },
              { transaction: t }
            );

            if (req.files && req.files.thumbnail) {
              const videoThumbNailId = await workoutVideosModel.findOne(
                {
                  where: { workoutId: workoutId.id },
                  attributes: ["thumbNailId"],
                },
                { transaction: t }
              );

              await videoThumbnailsModel.update(
                {
                  name: req.files.thumbnail.name,
                  filename: req.files.thumbnail.name,
                  savedLocation: imageData.Key,
                  updatedBy: req.decoded.id,
                  statusId: activeStatus,
                },
                {
                  where: {
                    id: {
                      [Op.eq]: videoThumbNailId.thumbNailId,
                    },
                  },
                  transaction: t,
                }
              );
            }

            const [instructorsData] =
              await workoutInstructorsModel.findOrCreate({
                where: {
                  name: instructorName,
                },
                defaults: {
                  uuid: uuidv4(),
                  name: instructorName,
                  statusId: activeStatus,
                  createdBy: req.decoded.id,
                },
                transaction: t,
              });

            if (req.files && req.files.video) {
              await workoutVideosModel.update(
                {
                  name: workoutName,
                  fileName: req.files.video.name,
                  savedLocation: videoData.Key,
                  size: req.files.video.size,
                  duration: duration,
                  instructorId: instructorsData.dataValues.id,
                  statusId: activeStatus,
                  updatedBy: req.decoded.id,
                },
                {
                  where: {
                    workoutId: {
                      [Op.eq]: workoutId.id,
                    },
                  },
                  transaction: t,
                }
              );
            } else {
              await workoutVideosModel.update(
                {
                  name: workoutName,
                  instructorId: instructorsData.dataValues.id,
                  updatedBy: req.decoded.id,
                },
                {
                  where: {
                    workoutId: {
                      [Op.eq]: workoutId.id,
                    },
                  },
                  transaction: t,
                }
              );
            }

            const goalsData = trainingGoal.map((goal) => {
              return {
                workoutId: workoutId.id,
                workoutCategoryId: 4,
                workoutSubCategoryId: goal,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const focusesData = focus.map((focus) => {
              return {
                workoutId: workoutId.id,
                workoutCategoryId: 3,
                workoutSubCategoryId: focus,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const programsData = programs.map((program) => {
              return {
                workoutId: workoutId.id,
                workoutCategoryId: 1,
                workoutSubCategoryId: program,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const musclesData = muscleGroups.map((muscle) => {
              return {
                workoutId: workoutId.id,
                workoutCategoryId: 2,
                workoutSubCategoryId: muscle,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });
            const dataToInsert = [
              ...focusesData,
              ...musclesData,
              ...goalsData,
              ...programsData,
            ];

            await workoutVideoDetailsModel.destroy({
              where: { workoutId: workoutId.id },
            });

            await workoutVideoDetailsModel.bulkCreate(dataToInsert, {
              transaction: t,
            });
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (workoutsUpdateData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_UPDATE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  updateWorkoutStatus: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { uuid, status },
      } = req;

      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const activeStatuses = await getActiveStatuses();
      const statusId = activeStatuses?.find(
        (rec) => rec.name === statuses[status]
      ).id;

      const statusUpdatedData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            await workoutVideosModel.update(
              { statusId },
              {
                where: {
                  uuid,
                },
              }
            );

            const videoData = await workoutVideosModel.findOne({
              where: { uuid },
            });

            await workoutVideoDetailsModel.update(
              { statusId },
              {
                where: {
                  workoutId: videoData.workoutId,
                },
              }
            );

            await userWorkoutPlansModel.update(
              { statusId },
              {
                where: {
                  planOrVideoId: videoData.id,
                  type: savedWorkoutType.video,
                },
                transaction: t,
              }
            );

            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (statusUpdatedData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("STATUS_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("STATUS_UPDATE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  saveWorkoutForUser: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const getVideoId = await workoutVideosModel.findOne({
        where: {
          [Op.and]: [{ uuid: req.params.uuid }, { isDeleted: 0 }],
        },
      });

      if (!getVideoId)
        throw new handleError(translateObj.__("DELETED_VIDEO"), 422);

      const isVideoAlreadySaved = await userWorkoutPlansModel.findOne({
        where: {
          [Op.and]: [
            { planOrVideoId: getVideoId.id },
            { userId: req.decoded.id },
            { type: savedWorkoutType.video },
          ],
        },
      });

      const messageKey = isVideoAlreadySaved ? "VIDEO_UNSAVED" : "VIDEO_SAVED";
      const isSaved = isVideoAlreadySaved ? 0 : 1;

      let savedWorkoutData;
      if (isVideoAlreadySaved) {
        savedWorkoutData = await userWorkoutPlansModel.destroy({
          where: {
            [Op.and]: [
              { planOrVideoId: getVideoId.id },
              { userId: req.decoded.id },
              { type: savedWorkoutType.video },
            ],
          },
        });
      } else {
        savedWorkoutData = await userWorkoutPlansModel.create({
          uuid: uuidv4(),
          userId: req.decoded.id,
          type: savedWorkoutType.video,
          planOrVideoId: getVideoId.id,
          videoSavedDate: moment().utc().format(dateFormat1),
          statusId: activeStatus,
          createdBy: req.decoded.id,
        });
      }

      if (!savedWorkoutData) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(
          res,
          successStatus,
          { isLiked: isSaved },
          translateObj.__(messageKey),
          200
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getSavedWorkout: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const userData = await userModel.findOne({
        where: {
          uuid: req.params.userUuid,
        },
      });

      const { count, rows } = await userWorkoutPlansModel.findAndCountAll({
        distinct: true,
        attributes: ["planOrVideoId", "type"],
        where: {
          [Op.and]: [
            {
              userId: userData.id,
            },
            { statusId: activeStatus },
          ],
        },
        offset: (page - 1) * pageSize,
        limit: pageSize,
      });
      const videoIds = rows.map((row) => {
        if (savedWorkoutType.video === row.type) return row.planOrVideoId;
      });
      const planIds = rows.map((row) => {
        if (savedWorkoutType.plan === row.type) return row.planOrVideoId;
      });
      const result = await workoutVideosModel.findAll({
        attributes: ["uuid", "duration", "id"],
        include: [
          {
            model: workoutsModel,
            attributes: ["name"],
            include: [
              {
                model: workoutVideoDetailsModel,
                attributes: ["workoutSubCategoryId"],
                include: [
                  {
                    model: workoutCategoriesModel,
                    attributes: ["name"],
                    where: { name: "program" },
                  },
                  {
                    model: workoutSubCategoriesModel,
                    attributes: ["name"],
                  },
                ],
              },
            ],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
          },
          {
            model: videoThumbnailsModel,
            attributes: ["savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.video },
            required: false,
          },
        ],
        where: {
          id: {
            [Op.in]: videoIds,
          },
        },
      });

      const savedPlans = await workoutPlansModel.findAll({
        attributes: [
          "id",
          "uuid",
          "name",
          "description",
          "noOfWorkouts",
          "createdAt",
        ],
        include: [
          {
            model: workoutPlanCategoriesModel,
            attributes: ["workoutSubCategoryId"],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: workoutPlanThumbnailsModel,
            attributes: ["savedLocation"],
          },
        ],
        where: {
          id: {
            [Op.in]: planIds,
          },
        },
      });

      savedPlans.map((data) => {
        const signedLink = getSignedUrlFromS3(
          data.workout_plan_thumbnail.savedLocation
        );
        data.workout_plan_thumbnail.savedLocation = signedLink;
        data.dataValues.isVideo = false;
      });

      if (rows) {
        const savedVideo = flattenSavedWorkouts(result);
        const responseData = [...savedVideo, ...savedPlans];
        responseData.map((data) => {
          if (data.workout_name) {
            data.isVideo = true;
          }
        });
        return createResponse(
          res,
          successStatus,
          {
            records: responseData,
            totalCount: count,
            page,
            pageSize,
          },
          translateObj.__("WORKOUT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getScheduledWorkouts: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const userData = await userModel.findOne({
        where: {
          uuid: req.params.userUuid,
        },
      });
      const { count, rows } =
        await plannedWorkoutUserDetailsModel.findAndCountAll({
          distinct: true,
          attributes: ["workoutVideoId"],
          where: {
            [Op.and]: [
              {
                userId: userData.id,
              },
              { statusId: activeStatus },
              {
                workoutSessionDate: {
                  [Op.gte]: moment().utc().startOf("day"),
                },
              },
            ],
          },
          offset: (page - 1) * pageSize,
          limit: pageSize,
        });

      const videoIds = rows.map((row) => {
        return row.workoutVideoId;
      });

      const result = await workoutVideosModel.findAll({
        attributes: ["uuid", "duration"],
        include: [
          {
            model: workoutsModel,
            attributes: ["name"],
            include: [
              {
                model: workoutVideoDetailsModel,
                attributes: ["workoutSubCategoryId"],
                include: [
                  {
                    model: workoutCategoriesModel,
                    attributes: ["name"],
                    where: { name: "program" },
                  },
                  {
                    model: workoutSubCategoriesModel,
                    attributes: ["name"],
                  },
                ],
              },
            ],
          },
          {
            model: workoutInstructorsModel,
            attributes: ["name"],
          },
          {
            model: videoThumbnailsModel,
            attributes: ["savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.video },
            required: false,
          },
          {
            model: plannedWorkoutUserDetailsModel,
            attributes: ["id", "workoutSessionDate"],
            where: { userId: req.decoded.id },
            required: false,
          },
        ],
        where: {
          id: {
            [Op.in]: videoIds,
          },
        },
      });

      if (rows) {
        const data = flattenSavedWorkouts(result);

        return createResponse(
          res,
          successStatus,
          { records: data, totalCount: count, page, pageSize },
          translateObj.__("WORKOUT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getWorkoutsHistory: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const { count, rows } = await completedWorkoutsModel.findAndCountAll({
        distinct: true,
        attributes: ["isCompleted", "completionDate"],
        include: [
          {
            model: workoutVideosModel,
            attributes: ["id", "uuid", "duration", "size"],
            include: [
              {
                model: workoutsModel,
                attributes: ["name"],
                include: [
                  {
                    model: workoutVideoDetailsModel,
                    attributes: ["workoutSubCategoryId"],
                    include: [
                      {
                        model: workoutCategoriesModel,
                        attributes: ["name"],
                        where: { name: "program" },
                      },
                      {
                        model: workoutSubCategoriesModel,
                        attributes: ["name"],
                      },
                    ],
                  },
                ],
              },
              {
                model: workoutInstructorsModel,
                attributes: ["name"],
              },
              {
                model: videoThumbnailsModel,
                attributes: ["savedLocation"],
              },
              {
                model: statusModel,
                attributes: ["name"],
              },
              {
                model: userWorkoutPlansModel,
                attributes: ["id", "userId"],
                where: { userId: req.decoded.id, type: savedWorkoutType.video },
                required: false,
              },
            ],
          },
        ],
        where: {
          [Op.and]: [
            {
              userId: req.decoded.id,
            },
            { statusId: activeStatus },
          ],
        },
        offset: (page - 1) * pageSize,
        limit: pageSize,
      });

      if (rows) {
        const data = rows.map((video) => {
          return {
            isCompleted: video.isCompleted,
            completionDate: video.completionDate,
            workout_video: flattenWorkouts([video.workout_video], false),
          };
        });
        return createResponse(
          res,
          successStatus,
          { records: data, totalCount: count, page, pageSize },
          translateObj.__("WORKOUT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("WORKOUT_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  scheduleWorkout: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        uuid: "required",
        plannedDate: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const {
        body: { uuid, plannedDate },
      } = req;

      const videoData = await workoutVideosModel.findOne({
        where: { uuid },
      });

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const isAlreadyPlanned = await plannedWorkoutUserDetailsModel.findOne({
        where: {
          [Op.and]: [
            {
              workoutVideoId: videoData.id,
            },
            {
              userId: req.decoded.id,
            },
          ],
        },
      });

      let WorkoutPlannedData;
      if (isAlreadyPlanned) {
        WorkoutPlannedData = await plannedWorkoutUserDetailsModel.update(
          {
            workoutSessionDate: moment(new Date(plannedDate))
              .utc()
              .format(dateFormat3),
          },
          {
            where: {
              id: isAlreadyPlanned.id,
            },
          }
        );
      } else {
        WorkoutPlannedData = await plannedWorkoutUserDetailsModel.create({
          userId: req.decoded.id,
          workoutSessionDate: moment(new Date(plannedDate))
            .utc()
            .format(dateFormat3),
          workoutVideoId: videoData.id,
          isWorkoutCompleted: 0,
          statusId: activeStatus,
          createdBy: req.decoded.id,
        });
      }

      if (!WorkoutPlannedData)
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("WORKOUT_SCHEDULED"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  markWorkoutCompleted: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        workoutVideoId: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const {
        body: { workoutVideoId },
      } = req;

      const completedWorkoutData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            await plannedWorkoutUserDetailsModel.update(
              {
                isWorkoutCompleted: 1,
              },
              {
                where: {
                  [Op.and]: [
                    { workoutSessionDate: moment().utc().startOf("day") },
                    { userId: req.decoded.id },
                    { workoutVideoId },
                    { isWorkoutCompleted: 0 },
                  ],
                },
              }
            );

            completedWorkoutsModel
              .findOne({
                where: {
                  [Op.and]: [{ userId: req.decoded.id }, { workoutVideoId }],
                },
              })
              .then(function (obj) {
                // update if not mark completed already
                if (obj)
                  return obj.update({
                    completionDate: moment().utc().startOf("day"),
                  });
                // insert if not mark completed already
                return completedWorkoutsModel.create({
                  userId: req.decoded.id,
                  workoutVideoId,
                  completionDate: moment().utc().startOf("day"),
                  isCompleted: 1,
                  statusId: activeStatus,
                  createdBy: req.decoded.id,
                });
              });

            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (!completedWorkoutData)
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("WORKOUT_MARK_COMPLETED"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  saveUsersBestTime: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        distanceCovered: "required",
        bestTime: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const activeStatuses = await getActiveStatuses();
      const activeStatus = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      ).id;

      const {
        body: { distanceCovered, bestTime },
      } = req;

      const userBestTimeData = await workoutBestTimeModel
        .findOne({
          where: {
            [Op.and]: [{ userId: req.decoded.id }, { distanceCovered }],
          },
        })
        .then(function (obj) {
          // update time if distance already covered
          if (obj)
            return obj.update({
              bestTime,
              updatedBy: req.decoded.id
            });
          // insert if new distance covered by user
          return workoutBestTimeModel.create({
            userId: req.decoded.id,
            distanceCovered,
            bestTime,
            statusId: activeStatus,
            createdBy: req.decoded.id,
          });
        });

      if (!userBestTimeData)
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("BEST_TIME_SAVED"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
};
