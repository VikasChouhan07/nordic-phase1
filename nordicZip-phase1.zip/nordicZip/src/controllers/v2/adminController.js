const model = require("../../models/index");
const userModel = model.user;
const otpModel = model.otp;
const statusModel = model.status;
const moment = require("moment");
const { translate } = require("../../helpers/multilingual");
const { handleError } = require("../../helpers/errorHandling");
const {
  response: {
    statuses: { success: successStatus, error: errorStatus },
    create: createResponse,
  },
} = require("../../helpers/common");
const { validate } = require("../../helpers/validator");
const { comparePassword, cryptPassword } = require("../../helpers/hashing");
const {
  createSortBy,
  addFiltersToWhereClause,
  statuses,
} = require("../../helpers/sequelize");
const { checkOtp } = require("./authController");
const { dateFormat1 } = require("../../helpers/dates");
const workoutInstructorsModel = model.workout_instructor;
const usersTypesModel = model.user_type;
const { uploadFilesToS3 } = require("../../helpers/aws");
const { userTypes } = require("../../helpers/users");

module.exports = {
  getUsers: async (req, res) => {
    try {
      const validations = {
        page: "required",
        pageSize: "required",
      };

      // Call Translate
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const sortByDefault = ["createdAt", "DESC"];

      const {
        sortBy: sortByParams,
        search: filterString,
        status: filterStatus,
        fromDate,
        toDate,
      } = req.query;
      let whereClause = {};

      let statusData;
      if (filterStatus) {
        statusData = await statusModel.findOne({
          where: { name: filterStatus },
        });
      }

      const sortBy = sortByParams?.length
        ? createSortBy(sortByParams)
        : sortByDefault;

      const searchByColumns = ["firstName", "email"];
      const dateFilterColumn = "registrationDate";
      if (filterString || statusData || fromDate || toDate) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          statusId: statusData?.dataValues.id || "",
          fromDate,
          toDate,
          dateFilterColumn,
        };
        whereClause = addFiltersToWhereClause(filters);
      }

      const userData = await usersTypesModel.findOne({
        where: { name: userTypes.user },
      });

      whereClause.userTypeId = userData.id;

      const users = await userModel.findAll({
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
      });

      const totalUsers = await userModel.count({
        where: whereClause,
      });

      if (users) {
        return createResponse(
          res,
          true,
          { records: users, totalCount: totalUsers, page, pageSize },
          translateObj.__("USERS_FETCHED"),
          200
        );
      } else {
        return createResponse(
          res,
          true,
          {},
          translateObj.__("USERS_NOT_AVAILABLE"),
          400
        );
      }
    } catch (e) {
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  changePassword: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const userUuid = req.params.uuid;
      const body = req.body;

      const validationObj = {
        newPassword: "required|minLength:8|maxLength:45",
        confirmPassword: "required|minLength:8|maxLength:45",
      };

      //if user using forgot password functionality we'll get an OTP else Old password
      if (body.otp) {
        const validations = {
          ...validationObj,
          otp: "required|minLength:4|maxLength:6",
        };

        const matched = await validate(req.body, validations);
        if (matched.status === false) {
          throw new handleError(translateObj.__("VALIDATION_ERROR"), 400);
        }

        //Verifying OTP
        const otpData = await otpModel.findOne({
          where: {
            otpPassword: body.otp.toString(),
          },
        });

        if (!otpData)
          throw new handleError(translateObj.__("INVALID_OTP"), 400);

        const otpExpiry = moment(otpData.otpSentAt)
          .add(process.env.OTP_EXPIRES_IN, process.env.OTP_EXPIRES_IN_TIME_UNIT)
          .format("YYYY-MM-DD HH:mm:ss");
        const currentTime = moment().format(dateFormat1);

        if (!moment(otpExpiry).isAfter(currentTime, "time"))
          throw new handleError(translateObj.__("OTP_EXPIRED"), 401);

        //delete OTP from table if matched
        await otpModel.destroy({ where: { otpPassword: body.otp } });
      } else {
        const validations = {
          ...validationObj,
          oldPassword: "required|minLength:8|maxLength:45",
        };

        const matched = await validate(req.body, validations);
        if (matched.status === false) {
          throw new handleError(translateObj.__("VALIDATION_ERROR"), 400);
        }

        //find user by uuid to match saved password with old password
        const userData = await userModel.findOne({
          where: { uuid: userUuid },
        });

        const passwordComparisonResult = await comparePassword(
          body.oldPassword,
          userData.dataValues.password
        );

        if (!passwordComparisonResult) {
          throw new handleError(translateObj.__("INVALID_OLD_PASSWORD"), 400);
        }
      }

      if (body.newPassword != body.confirmPassword) {
        throw new handleError(translateObj.__("PASSWORD_NOT_MATCHED"), 400);
      }

      const hashedPassword = await cryptPassword(body.newPassword.trim());

      //update user password if everything is validated
      const updatedUser = await userModel.update(
        { password: hashedPassword },
        { where: { uuid: userUuid } }
      );

      if (updatedUser) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PASSWORD_CHANGED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PASSWORD_CHANGE_ERROR"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  update: async (req, res) => {
    try {
      const validations = {
        firstName: "required|maxLength:255",
      };

      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          403,
          validationData
        );
      }
      const {
        body: { firstName },
        params: { uuid },
      } = req;

      let updateData = { firstName };

      if (req.files) {
        const imageObj = await uploadFilesToS3(
          [req.files.imageLocation],
          process.env.AWS_S3_PROFILE_PHOTOS_FOLDER_NAME
        );
        if (!imageObj) {
          throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
        }

        updateData = { firstName, imageLocation: imageObj.Location };
      }

      const updatedData = await userModel.update(updateData, {
        where: {
          uuid,
        },
      });

      if (updatedData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PROFILE_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          errorStatus,
          {},
          translateObj.__("PROFILE_UPDATE_ERROR"),
          500
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  updateStatus: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { status, uuid },
      } = req;
      //return if send an invalid status
      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const statusData = await statusModel.findOne({
        where: {
          name: status.trim(),
        },
      });

      //update statusId in users after taking statusId from status table
      const updatedUser = await userModel.update(
        { statusId: statusData.dataValues.id },
        { where: { uuid: uuid } }
      );

      if (updatedUser[0]) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("STATUS_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("STATUS_UPDATE_ERROR"),
          204
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  updateEmail: async (req, res) => {
    try {
      checkOtp(req, res);
      const {
        body: { email },
        params: { uuid },
      } = req;

      const updatedEmail = await userModel.update(
        { email: email.toLowerCase().trim() },
        { where: { uuid } }
      );

      const translateObj = translate(req.headers.lang);
      if (updatedEmail[0]) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("EMAIL_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("EMAIL_UPDATE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getAdmin: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const adminData = await userModel.findOne({
        where: {
          uuid: req.params.uuid,
        },
        attributes: [
          "firstName",
          "lastName",
          "uuid",
          "email",
          "imageLocation",
          "gender",
          "registrationDate",
        ],
      });
      if (adminData) {
        return createResponse(
          res,
          successStatus,
          adminData,
          translateObj.__("USER_FETCHED"),
          201
        );
      } else {
        return createResponse(
          res,
          successStatus,
          adminData,
          translateObj.__("USER_NOT_AVAILABLE"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getInstructors: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);

      const { name: filterString } = req.query;
      const searchByColumns = ["name"];
      const filters = {
        filterString,
        searchByColumns,
      };

      const whereClause = addFiltersToWhereClause(filters);
      let instructors = await workoutInstructorsModel.findAll({
        where: whereClause,
        attributes: ["name"],
      });

      if (!instructors[0]) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("INSTRUCTOR_NOT_FOUND"),
          404
        );
      }

      instructors = instructors.map((instructor) => {
        return instructor.dataValues.name;
      });

      return createResponse(
        res,
        successStatus,
        instructors,
        translateObj.__("INSTRUCTOR_FOUND"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
};
