const model = require("../../models/index");
const { translate } = require("../../helpers/multilingual");
const { handleError } = require("../../helpers/errorHandling");
const {
  response: {
    statuses: { success: successStatus, error: errorStatus },
    create: createResponse,
  },
} = require("../../helpers/common");
const { v4: uuidv4 } = require("uuid");
const { validate } = require("../../helpers/validator");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const {
  getActiveStatuses,
  statuses,
  createSortBy,
  addFiltersToWhereClause,
} = require("../../helpers/sequelize");
const { flatRecommendationData } = require("../../helpers/workouts");
const moment = require("moment");
const { dateFormat3 } = require("../../helpers/dates");
const { getSignedUrlFromS3 } = require("../../helpers/aws");
const { savedWorkoutType } = require("../../helpers/users");
const workoutRecommendations = model.workout_recommendation;
const recommendationWorkoutDetails = model.recommendation_workout_detail;
const workoutInstructorsModel = model.workout_instructor;
const workoutsModel = model.workout;
const workoutVideosModel = model.workout_video;
const statusModel = model.status;
const workoutSubCategoriesModel = model.workout_sub_category;
const userModel = model.user;
const usersOnboardingDetailsModel = model.user_onboarding_detail;
const videoThumbnailsModel = model.video_thumbnail;
const workoutVideoDetailsModel = model.workout_video_detail;
const workoutCategoriesModel = model.workout_category;
const userWorkoutPlansModel = model.user_workout_plan;

workoutVideosModel.hasOne(workoutRecommendations, {
  foreignKey: "id",
  onDelete: "cascade",
});

workoutRecommendations.belongsTo(workoutVideosModel, {
  foreignKey: "workoutVideoId",
});

statusModel.hasOne(workoutRecommendations, {
  foreignKey: "id",
});
workoutRecommendations.belongsTo(statusModel, {
  foreignKey: "statusId",
});

workoutRecommendations.hasMany(recommendationWorkoutDetails, {
  foreignKey: "recommendationId",
  onDelete: "cascade",
});

recommendationWorkoutDetails.belongsTo(workoutRecommendations, {
  foreignKey: "id",
});

workoutsModel.hasOne(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(workoutsModel, {
  foreignKey: "workoutId",
});

workoutInstructorsModel.hasMany(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(workoutInstructorsModel, {
  foreignKey: "instructorId",
});

workoutSubCategoriesModel.hasMany(recommendationWorkoutDetails, {
  foreignKey: "id",
});
recommendationWorkoutDetails.belongsTo(workoutSubCategoriesModel, {
  foreignKey: "workoutSubCategoryId",
});

videoThumbnailsModel.hasOne(workoutVideosModel, {
  foreignKey: "id",
});
workoutVideosModel.belongsTo(videoThumbnailsModel, {
  foreignKey: "thumbNailId",
});
userModel.hasOne(usersOnboardingDetailsModel);
usersOnboardingDetailsModel.belongsTo(userModel);

module.exports = {
  addRecommendation: async (req, res) => {
    try {
      const validations = {
        workoutVideoId: "required",
        fromPublishDate: "required",
        toPublishDate: "required",
        trainingGoals: "required",
        status: "required",
      };

      // Call Translate
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );

      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const {
        body: { workoutVideoId, fromPublishDate, toPublishDate, status },
      } = req;

      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const startDate = moment(new Date(fromPublishDate)).utc().startOf("day");
      const endDate = moment(new Date(toPublishDate)).utc().startOf("day");

      const recommendationExist = await workoutRecommendations.findOne({
        where: {
          [Op.or]: [
            {
              fromPublishDate: {
                [Op.between]: [startDate, endDate],
              },
            },
            {
              toPublishDate: {
                [Op.between]: [startDate, endDate],
              },
            },
            {
              [Op.and]: [
                {
                  fromPublishDate: {
                    [Op.lte]: startDate,
                  },
                },
                {
                  toPublishDate: {
                    [Op.gte]: endDate,
                  },
                },
              ],
            },
          ],
          isDeleted: 0,
        },
      });

      if (recommendationExist)
        throw new handleError(translateObj.__("RECOMMENDATION_EXISTS"), 403);

      const trainingGoals = req.body.trainingGoals.split(",");

      const activeStatuses = await getActiveStatuses();
      const { id: recommendationStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses[status]
      );

      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const recommendationData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            let recommendation = await workoutRecommendations.create(
              {
                uuid: uuidv4(),
                workoutVideoId,
                fromPublishDate: moment(new Date(fromPublishDate))
                  .utc()
                  .format(dateFormat3),
                toPublishDate: moment(new Date(toPublishDate))
                  .utc()
                  .format(dateFormat3),
                createdBy: req.decoded.id,
                statusId: recommendationStatus,
                isDeleted: 0,
              },
              { transaction: t }
            );

            const trainingGoalsData = trainingGoals.map((goal) => {
              return {
                recommendationId: recommendation.id,
                workoutCategoryId: 4,
                workoutSubCategoryId: goal,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });

            await recommendationWorkoutDetails.bulkCreate(trainingGoalsData, {
              transaction: t,
            });
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (!recommendationData) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("RECOMMENDATION_ADDED"),
          200
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  editRecommendation: async (req, res) => {
    try {
      const validations = {
        workoutVideoId: "required",
        fromPublishDate: "required",
        toPublishDate: "required",
        trainingGoals: "required",
        status: "required",
      };

      // Call Translate
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );

      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const {
        body: { workoutVideoId, fromPublishDate, toPublishDate, status },
        params: { id },
      } = req;

      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const startDate = moment(new Date(fromPublishDate)).utc().startOf("day");
      const endDate = moment(new Date(toPublishDate)).utc().startOf("day");

      const recommendationExist = await workoutRecommendations.findOne({
        where: {
          [Op.or]: [
            {
              [Op.and]: [
                {
                  fromPublishDate: {
                    [Op.between]: [startDate, endDate],
                  },
                },
                // {
                //   id: { [Op.ne]: id },
                // },
              ],
            },
            {
              [Op.and]: [
                {
                  toPublishDate: {
                    [Op.between]: [startDate, endDate],
                  },
                },
                // {
                //   id: { [Op.ne]: id },
                // },
              ],
            },
            {
              [Op.and]: [
                {
                  fromPublishDate: {
                    [Op.lte]: startDate,
                  },
                },
                {
                  toPublishDate: {
                    [Op.gte]: endDate,
                  },
                },
                // {
                //   id: { [Op.ne]: id },
                // },
              ],
            },
          ],
          isDeleted: 0,
          id: { [Op.ne]: id },
        },
      });

      if (recommendationExist)
        throw new handleError(translateObj.__("RECOMMENDATION_EXISTS"), 403);

      const trainingGoals = req.body.trainingGoals.split(",");

      const activeStatuses = await getActiveStatuses();
      const { id: recommendationStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses[status]
      );

      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const recommendationData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            await workoutRecommendations.update(
              {
                workoutVideoId,
                fromPublishDate: moment(new Date(fromPublishDate))
                  .utc()
                  .format(dateFormat3),
                toPublishDate: moment(new Date(toPublishDate))
                  .utc()
                  .format(dateFormat3),
                updatedBy: req.decoded.id,
                statusId: recommendationStatus,
              },
              {
                where: { id },
              },
              { transaction: t }
            );

            const trainingGoalsData = trainingGoals.map((goal) => {
              return {
                recommendationId: id,
                workoutCategoryId: 4,
                workoutSubCategoryId: goal,
                statusId: activeStatus,
                createdBy: req.decoded.id,
              };
            });

            await recommendationWorkoutDetails.destroy({
              where: { recommendationId: id },
            });

            await recommendationWorkoutDetails.bulkCreate(trainingGoalsData, {
              transaction: t,
            });
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (!recommendationData) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("RECOMMENDATION_UPDATED"),
          200
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getRecommendation: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }
      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);
      const sortByDefault = ["createdAt", "DESC"];
      const {
        sortBy: sortByParams,
        search: filterString,
        status: filterStatus,
      } = req.query;
      let whereClause = {};

      let statusId;
      if (filterStatus) {
        const activeStatuses = await getActiveStatuses();
        statusId = activeStatuses?.find(
          (rec) => rec.name === statuses[filterStatus]
        ).id;
      }

      const sortBy = sortByParams?.length
        ? createSortBy(sortByParams)
        : sortByDefault;

      const searchByColumns = [
        "workout_video.workout_instructor.name",
        "workout_video.workout.name",
      ];
      if (filterString || filterStatus) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          statusId: statusId || "",
        };
        whereClause = addFiltersToWhereClause(filters);
      }
      whereClause.isDeleted = 0;

      const { count, rows } = await workoutRecommendations.findAndCountAll({
        subQuery: false,
        distinct: true,
        attributes: [
          "id",
          "uuid",
          "workoutVideoId",
          "fromPublishDate",
          "toPublishDate",
        ],
        include: [
          {
            model: workoutVideosModel,
            attributes: ["workoutId"],
            include: [
              {
                model: workoutsModel,
                attributes: ["name"],
              },
              {
                model: workoutInstructorsModel,
                attributes: ["name"],
              },
            ],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: recommendationWorkoutDetails,
            attributes: ["id"],
            include: [
              {
                model: workoutSubCategoriesModel,
                attributes: [
                  [
                    Sequelize.fn(
                      "GROUP_CONCAT",
                      Sequelize.col(
                        "recommendation_workout_details.workout_sub_category.name"
                      )
                    ),
                    "names",
                  ],
                ],
              },
            ],
          },
        ],
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
        group: ["id"],
      });

      const flattenData = flatRecommendationData(rows);

      if (!rows) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(
          res,
          successStatus,
          {
            records: flattenData,
            totalCount: count?.length,
            page,
            pageSize,
          },
          translateObj.__("RECOMMENDATION_FOUND"),
          200
        );
      }
    } catch (e) {
      console.log(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  /**
   * @description This function is for getting a recommendation for admin to edit
   * @param {*} req
   * @param {*} res
   * @returns
   */
  getRecommendationOfAdmin: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { uuid },
      } = req;
      if (!uuid) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      }

      const activeStatuses = await getActiveStatuses();

      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const recommendationData = await workoutRecommendations.findOne({
        where: { uuid: uuid },
        attributes: ["id", "fromPublishDate", "toPublishDate"],
        include: [
          {
            model: workoutVideosModel,
            attributes: [["id", "workoutVideoId"], "savedLocation"],
            where: { statusId: activeStatus },
            required: false,
            include: [
              {
                model: workoutsModel,
                attributes: ["name"],
              },
              {
                model: workoutInstructorsModel,
                attributes: ["name"],
              },
            ],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: recommendationWorkoutDetails,
            attributes: ["workoutSubCategoryId"],
            include: [
              {
                model: workoutSubCategoriesModel,
                attributes: ["name"],
              },
            ],
          },
        ],
      });

      if (!recommendationData) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      }

      if (recommendationData.workout_video) {
        recommendationData.workout_video.savedLocation = getSignedUrlFromS3(
          recommendationData.workout_video.savedLocation
        );
      }
      return createResponse(
        res,
        successStatus,
        recommendationData,
        translateObj.__("RECOMMENDATION_FOUND"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  publishRecommendation: async (req, res) => {
    try {
      const validations = {
        uuid: "required",
      };

      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.params,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          403,
          validationData
        );
      }

      const {
        body: { fromPublishDate, toPublishDate },
        params: { uuid, publish },
      } = req;

      if (!Object.values(statuses).includes(publish))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const recommendationVideoDisabled = await workoutRecommendations.findOne({
        where: { uuid },
      });

      const videoData = await workoutVideosModel.findOne({
        where: {
          [Op.and]: [
            { id: recommendationVideoDisabled.workoutVideoId },
            { statusId: 1 },
          ],
        },
      });

      if (!videoData)
        throw new handleError(translateObj.__("VIDEO_DISABLED"), 422);

      //check recommendation already exist or not when publish any recommendation
      if (publish == statuses.active) {
        const startDate = moment(new Date(fromPublishDate))
          .utc()
          .startOf("day");
        const endDate = moment(new Date(toPublishDate)).utc().startOf("day");

        const recommendationExist = await workoutRecommendations.findOne({
          where: {
            [Op.or]: [
              {
                [Op.and]: [
                  {
                    fromPublishDate: {
                      [Op.between]: [startDate, endDate],
                    },
                  },
                  {
                    uuid: { [Op.ne]: uuid },
                  },
                ],
              },
              {
                [Op.and]: [
                  {
                    toPublishDate: {
                      [Op.between]: [startDate, endDate],
                    },
                  },
                  {
                    uuid: { [Op.ne]: uuid },
                  },
                ],
              },
              {
                [Op.and]: [
                  {
                    fromPublishDate: {
                      [Op.lte]: startDate,
                    },
                  },
                  {
                    toPublishDate: {
                      [Op.gte]: endDate,
                    },
                  },
                  {
                    isDeleted: 0,
                  },
                  {
                    uuid: { [Op.ne]: uuid },
                  },
                ],
              },
            ],
          },
        });

        if (recommendationExist)
          throw new handleError(translateObj.__("RECOMMENDATION_EXISTS"), 403);
      }
      const activeStatuses = await getActiveStatuses();
      const { id: recommendationStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses[publish]
      );

      let publishData = { statusId: recommendationStatus };
      let message = translateObj.__("RECOMMENDATION_UNPUBLISHED");

      //update recommendation publishDate only when publish any recommendation
      if (publish == statuses.active) {
        message = translateObj.__("RECOMMENDATION_PUBLISHED");
        publishData = {
          ...publishData,
          ...{
            fromPublishDate: moment(new Date(fromPublishDate))
              .utc()
              .format(dateFormat3),
            toPublishDate: moment(new Date(toPublishDate))
              .utc()
              .format(dateFormat3),
          },
        };
      }

      const publishRecommendation = await workoutRecommendations.update(
        publishData,
        {
          where: { uuid },
        }
      );

      if (!publishRecommendation) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(res, successStatus, {}, message, 200);
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  deleteRecommendation: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { uuid },
      } = req;

      const recommendationDeleteData = await workoutRecommendations.destroy({
        where: { uuid },
      });

      if (recommendationDeleteData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("RECOMMENDATION_DELETED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("RECOMMENDATION_DELETE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
  getTodaysRecommendation: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { userUuid },
      } = req;

      const activeStatuses = await getActiveStatuses();
      const { id: activeStatusId } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      // Verify User
      const userData = await userModel.findOne({
        attributes: ["id"],
        where: {
          uuid: userUuid,
        },
        include: [
          {
            model: usersOnboardingDetailsModel,
            attributes: ["goalCategoryId"],
          },
        ],
      });
      console.log(`userData`, userData);
      if (!userData)
        throw new handleError(translateObj.__("USER_NOT_AVAILABLE"), 404);

      const userGoal = userData.user_onboarding_detail.goalCategoryId;
      const recommendationData = await workoutRecommendations.findAll({
        attributes: ["uuid", "workoutVideoId"],
        include: [
          {
            model: recommendationWorkoutDetails,
            attributes: ["workoutCategoryId", "workoutSubCategoryId"],
            where: { workoutSubCategoryId: userGoal },
          },
        ],
        where: {
          [Op.and]: [
            {
              fromPublishDate: {
                [Op.lte]: moment().utc().startOf("day"),
              },
            },
            {
              toPublishDate: {
                [Op.gte]: moment().utc().startOf("day"),
              },
            },
            {
              statusId: activeStatusId,
            },
            {
              isDeleted: 0,
            },
          ],
        },
      });

      const videoDetailsQuery = [
        {
          model: workoutsModel,
          attributes: [["name", "workout_name"]],
          include: [
            {
              model: workoutVideoDetailsModel,
              attributes: ["workoutSubCategoryId"],
              include: [
                {
                  model: workoutCategoriesModel,
                  attributes: ["name"],
                  where: { name: "program" },
                },
                {
                  model: workoutSubCategoriesModel,
                  attributes: ["name"],
                },
              ],
            },
          ],
        },
        {
          model: workoutInstructorsModel,
          attributes: ["name"],
        },
        {
          model: videoThumbnailsModel,
          attributes: ["savedLocation"],
        },
        {
          model: userWorkoutPlansModel,
          attributes: ["id", "userId"],
          where: { userId: req.decoded.id, type: savedWorkoutType.video },
          required: false,
        },
      ];

      let whereQuery;

      //if recommendation not found send any random recommendation else send founded recommendation details
      if (!recommendationData?.length) {
        const userGoalWorkout = await workoutVideoDetailsModel.findOne({
          where: {
            [Op.and]: [
              {
                workoutSubCategoryId: userGoal,
              },
              {
                statusId: activeStatusId,
              },
            ],
          },
          order: [["createdAt", "DESC"]],
          limit: 1,
        });

        if (!userGoalWorkout) {
          const workoutWithRandomGoal = await workoutVideoDetailsModel.findOne({
            where: {
              statusId: activeStatusId,
            },
            order: [["createdAt", "DESC"]],
            limit: 1,
          });
          whereQuery = {
            workoutId: workoutWithRandomGoal.workoutId,
          }; /**Random goal */
        } else {
          whereQuery = { workoutId: userGoalWorkout.workoutId }; /** Goal */
        }
      } else {
        whereQuery = {
          id: recommendationData[0].workoutVideoId,
        }; /** Recommendation for today and according to Goal */
      }

      let recommendationDetails = {};
      recommendationDetails = await workoutVideosModel.findOne({
        where: whereQuery,
        attributes: ["uuid", "duration"],
        include: videoDetailsQuery,
      });

      if (!recommendationDetails) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("RECOMMENDATION_NOT_FOUND"),
          404
        );
      }
      recommendationDetails.video_thumbnail.savedLocation = getSignedUrlFromS3(
        recommendationDetails.video_thumbnail.savedLocation
      );

      recommendationDetails = {
        recommendationDetails,
        isLiked: recommendationDetails.user_workout_plans?.length
          ? true
          : false,
      };

      return createResponse(
        res,
        successStatus,
        recommendationDetails,
        translateObj.__("RECOMMENDATION_FOUND"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(res, errorStatus, {}, e.message, e.code);
    }
  },
};
