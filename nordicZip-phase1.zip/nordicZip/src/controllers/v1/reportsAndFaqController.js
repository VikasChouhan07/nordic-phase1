const model = require("../../models/index");
const { translate } = require("../../helpers/multilingual");
const { handleError } = require("../../helpers/errorHandling");
const Sequelize = require("sequelize");
const {
  response: {
    statuses: { success: successStatus, error: errorStatus },
    create: createResponse,
  },
} = require("../../helpers/common");
const { validate } = require("../../helpers/validator");
const userQueries = model.user_query;
const {
  getActiveStatuses,
  statuses,
  userQueryTypes,
  getQueriesType,
  queryFilters,
  addFiltersToWhereClause,
} = require("../../helpers/sequelize");
const { dateFormat2 } = require("../../helpers/dates");
const moment = require("moment");
const statusModel = model.status;
const userModel = model.user;
const Op = Sequelize.Op;

statusModel.hasOne(userQueries, {
  foreignKey: "id",
});
userQueries.belongsTo(statusModel, {
  foreignKey: "statusId",
});

userModel.hasOne(userQueries);
userQueries.belongsTo(userModel);

module.exports = {
  getFaqs: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }

      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const { search: filterString, status: filterStatus } = req.query;
      let whereClause = {};

      let statusData;
      if (filterStatus) {
        statusData = await statusModel.findOne({
          where: { name: filterStatus },
        });
      }

      const sortByDefault = ["createdAt", "DESC"];
      const searchByColumns = ["subject"];
      if (filterString || statusData) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          statusId: statusData?.dataValues.id || "",
        };
        whereClause = addFiltersToWhereClause(filters);
      }

      const queryTypes = await getQueriesType();
      const queryTypeId = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.faq
      ).id;

      whereClause.queryTypeId = queryTypeId;
      let { count, rows } = await userQueries.findAndCountAll({
        raw: true,
        where: whereClause,
        attributes: [
          "id",
          ["subject", "question"],
          ["queryDescription", "answer"],
        ],
        include: [
          {
            model: statusModel,
            attributes: ["name"],
          },
        ],
        offset: (page - 1) * pageSize,
        limit: pageSize,
        order: [sortByDefault],
      });

      rows = rows.map((obj) => {
        return {
          id: obj.id,
          question: obj.question,
          answer: obj.answer,
          status: obj["status.name"],
        };
      });

      return createResponse(
        res,
        successStatus,
        { records: rows, totalCount: count, page, pageSize },
        translateObj.__("FAQS_FOUND"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  postIssue: async (req, res) => {
    try {
      const validations = {
        subject: "required",
        description: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }

      const {
        body: { subject, description },
      } = req;
      const activeStatuses = await getActiveStatuses();
      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const queryTypes = await getQueriesType();
      const { id: queryTypeId } = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.report
      );

      const reportIssueData = await userQueries.create({
        userId: req.decoded.id,
        queryTypeId,
        subject,
        queryDescription: description,
        queryDate: moment().utc(),
        isResolved: 0,
        statusId: activeStatus,
        createdBy: req.decoded.id,
      });

      if (reportIssueData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("QUERY_ADDED"),
          201
        );
      } else {
        throw new handleError(translate.__("UNKNOWN_ERROR"), 422);
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  postFaq: async (req, res) => {
    try {
      const validations = {
        question: "required|maxLength:300",
        answer: "required|maxLength:1500",
        status: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { question, answer, status },
      } = req;

      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const activeStatuses = await getActiveStatuses();
      const { id: statusId } = activeStatuses?.find(
        (rec) => rec.name === statuses[status]
      );

      const queryTypes = await getQueriesType();
      const { id: queryTypeId } = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.faq
      );

      const faqData = await userQueries.create({
        userId: req.decoded.id,
        queryTypeId,
        subject: question,
        queryDescription: answer,
        queryDate: moment().utc().format(dateFormat2),
        isResolved: 0,
        statusId: statusId,
        createdBy: req.decoded.id,
      });

      if (faqData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("FAQ_ADDED"),
          201
        );
      } else {
        throw new handleError(translate.__("UNKNOWN_ERROR"), 422);
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getFaq: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);

      const faqData = await userQueries.findOne({
        where: {
          id: req.params.id,
        },
        attributes: [
          "id",
          ["subject", "question"],
          ["queryDescription", "answer"],
        ],
        include: [
          {
            model: statusModel,
            attributes: ["name"],
          },
        ],
      });

      if (faqData) {
        return createResponse(
          res,
          successStatus,
          faqData,
          translateObj.__("FAQ_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("FAQ_NOT_FOUND"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },

  deleteFaq: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const faqData = await userQueries.destroy({
        where: {
          id: req.params.id,
        },
      });

      if (faqData) {
        return createResponse(
          res,
          successStatus,
          faqData,
          translateObj.__("FAQ_DELETED"),
          200
        );
      } else {
        return createResponse(
          res,
          errorStatus,
          {},
          translateObj.__("FAQ_UPDATE_ERROR"),
          500
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  editFaq: async (req, res) => {
    try {
      const validations = {
        question: "required",
        answer: "required",
        status: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.body,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { question, answer, status },
        params: { id },
      } = req;

      if (!Object.values(statuses).includes(status))
        throw new handleError(translateObj.__("INVALID_STATUS"), 422);

      const activeStatuses = await getActiveStatuses();
      const { id: statusId } = activeStatuses?.find(
        (rec) => rec.name === statuses[status]
      );

      const updatedFaq = await userQueries.update(
        {
          subject: question,
          queryDescription: answer,
          statusId: statusId,
          updatedBy: req.decoded.id,
        },
        {
          where: { id },
        }
      );

      if (updatedFaq) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("FAQ_UPDATED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("FAQ_NOT_FOUND"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  deleteIssue: async (req, res) => {
    try {
      const validations = {
        id: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        req.params,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }

      const queryTypes = await getQueriesType();
      const queryTypeId = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.report
      ).id;

      const queryDeleteData = await userQueries.destroy({
        where: {
          [Op.and]: [{ id: req.params.id }, { queryTypeId }],
        },
      });

      if (queryDeleteData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("QUERY_DELETED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("QUERY_DELETE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  resolveIssue: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        id: "required",
        resolved: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.params,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }

      const {
        params: { id, resolved },
      } = req;

      if (resolved && !Object.values(queryFilters).includes(resolved))
        throw new handleError(translateObj.__("INVALID_INPUT"), 422);

      const issueResolvedData = await userQueries.update(
        {
          isResolved: resolved,
          updatedBy: req.decoded.id,
        },
        {
          where: { id },
        }
      );

      if (issueResolvedData) {
        return createResponse(
          res,
          successStatus,
          {},

          translateObj.__("ISSUE_RESOLVED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},

          translateObj.__("ISSUE_RESOLVED_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getQuery: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const queryTypes = await getQueriesType();
      const queryTypeId = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.report
      ).id;
      const faqData = await userQueries.findOne({
        where: {
          id: req.params.id,
          queryTypeId: queryTypeId,
        },
        attributes: [
          "id",
          "userId",
          "subject",
          "queryDescription",
          "isResolved",
          "queryDate",
          "queryStatusDescription",
          "queryResolvedDate",
        ],
        include: [
          {
            model: userModel,
            attributes: ["firstName", "id", "email"],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
        ],
      });

      if (faqData) {
        return createResponse(
          res,
          successStatus,
          faqData,
          translateObj.__("REPORT_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("DATA_NOT_FOUND"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getAllQueries: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }
      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);

      const { search: filterString, isResolved, fromDate, toDate } = req.query;
      let whereClause = {};

      if (isResolved && !Object.values(queryFilters).includes(isResolved))
        throw new handleError(translateObj.__("INVALID_INPUT"), 422);

      const searchByColumns = ["user.firstname", "user.email"];
      const sortBy = ["createdAt", "DESC"];
      const dateFilterColumn = "queryDate";
      if (filterString || fromDate || toDate) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          fromDate,
          toDate,
          dateFilterColumn,
        };
        whereClause = addFiltersToWhereClause(filters);
      }

      if (isResolved) whereClause.isResolved = isResolved;

      const queryTypes = await getQueriesType();
      const queryTypeId = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.report
      ).id;

      whereClause.queryTypeId = queryTypeId;
      const { count, rows } = await userQueries.findAndCountAll({
        subQuery: false,
        distinct: true,
        attributes: [
          "id",
          "queryTypeId",
          "subject",
          "queryDescription",
          "isResolved",
          "queryDate",
        ],
        include: [
          {
            model: userModel,
            attributes: ["firstName", "id", "email"],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
        ],
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
      });

      if (rows) {
        return createResponse(
          res,
          successStatus,
          {
            records: rows,
            totalCount: count,
            page,
            pageSize,
          },
          translateObj.__("QUERIES_FOUND"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("DATA_NOT_FOUND"),
          404
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getPrivacyPolicy: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const queryTypes = await getQueriesType();
      const queryTypeId = queryTypes?.find(
        (rec) => rec.name === userQueryTypes.privacyPolicy
      ).id;
      const privacyPolicy = await userQueries.findOne({
        where: { queryTypeId },
        attributes: ["subject", ["queryDescription", "privacyPolicy"]],
      });

      return createResponse(
        res,
        successStatus,
        privacyPolicy,
        translateObj.__("PRIVACY_POLICY_FOUND"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
};
