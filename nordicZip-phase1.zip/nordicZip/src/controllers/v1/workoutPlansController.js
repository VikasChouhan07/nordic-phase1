const model = require("../../models/index");
const { translate } = require("../../helpers/multilingual");
const { handleError } = require("../../helpers/errorHandling");
const {
  response: {
    statuses: { success: successStatus, error: errorStatus },
    create: createResponse,
  },
} = require("../../helpers/common");
const { v4: uuidv4 } = require("uuid");
const { validate } = require("../../helpers/validator");
const { uploadFilesToS3 } = require("../../helpers/aws");
const {
  getActiveStatuses,
  statuses,
  addFiltersToWhereClause,
} = require("../../helpers/sequelize");
const { getSignedUrlFromS3 } = require("../../helpers/aws");
const { flattenWorkouts } = require("../../helpers/workouts");
const { userTypes, savedWorkoutType } = require("../../helpers/users");
const Sequelize = require("sequelize");
const { dateFormat1 } = require("../../helpers/dates");
const moment = require("moment");
const Op = Sequelize.Op;
const userModel = model.user;
const usersTypesModel = model.user_type;
const workoutsModel = model.workout;
const workoutPlansModel = model.workout_plan;
const workoutPlanDetailsModel = model.workout_plan_detail;
const statusModel = model.status;
const workoutVideosModel = model.workout_video;
const workoutInstructorsModel = model.workout_instructor;
const videoThumbnailsModel = model.video_thumbnail;
const workoutVideoDetailsModel = model.workout_video_detail;
const workoutCategoriesModel = model.workout_category;
const workoutSubCategoriesModel = model.workout_sub_category;
const workoutPlanThumbnailsModel = model.workout_plan_thumbnail;
const userWorkoutPlansModel = model.user_workout_plan;
const plannedWorkoutUserDetailsModel = model.planned_workout_user_detail;
const workoutPlanCategoriesModel = model.workout_plan_category;

userWorkoutPlansModel.belongsTo(workoutPlansModel, {
  foreignKey: "planOrVideoId",
});

userWorkoutPlansModel.belongsTo(statusModel, {
  foreignKey: "statusId",
});

statusModel.hasOne(workoutPlansModel, {
  foreignKey: "id",
});
workoutPlansModel.belongsTo(statusModel, {
  foreignKey: "statusId",
});

workoutPlanThumbnailsModel.hasOne(workoutPlansModel, {
  foreignKey: "id",
});
workoutPlansModel.belongsTo(workoutPlanThumbnailsModel, {
  foreignKey: "thumbNailId",
});

workoutPlansModel.hasMany(workoutPlanDetailsModel, {
  foreignKey: "workoutPlanId",
  onDelete: "cascade",
});

workoutPlanDetailsModel.belongsTo(workoutPlansModel, {
  foreignKey: "id",
});

workoutVideosModel.hasMany(workoutPlanDetailsModel, {
  foreignKey: "id",
  onDelete: "cascade",
});
workoutPlanDetailsModel.belongsTo(workoutVideosModel, {
  foreignKey: "workoutVideoId",
});

workoutPlansModel.hasMany(workoutPlanCategoriesModel, {
  foreignKey: "workoutPlanId",
  onDelete: "cascade",
});

workoutCategoriesModel.hasMany(workoutPlanCategoriesModel);

workoutPlanCategoriesModel.belongsTo(workoutCategoriesModel, {
  foreignKey: "workoutCategoryId",
});

workoutSubCategoriesModel.hasMany(workoutPlanCategoriesModel);
workoutPlanCategoriesModel.belongsTo(workoutSubCategoriesModel, {
  foreignKey: "workoutSubCategoryId",
});

workoutPlansModel.hasOne(userWorkoutPlansModel, {
  foreignKey: "planOrVideoId",
});

userWorkoutPlansModel.belongsTo(workoutPlansModel, {
  foreignKey: "id",
});

module.exports = {
  addWorkoutPlan: async (req, res) => {
    try {
      const validations = {
        name: "required|maxLength:200",
        thumbnail: "required",
        description: "required|maxLength:1500",
        totalWorkouts: "required",
        isPublish: "required",
        videos: "required",
        programs: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        { ...req.body, ...req.files },
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { name, description, totalWorkouts, isPublish, videos, programs },
      } = req;
      const videoIds = videos.split(",");
      const programIds = programs.split(",");
      const imageData = await uploadFilesToS3(
        [req.files.thumbnail],
        process.env.AWS_S3_WORKOUT_VIDEO_THUMBNAILS_FOLDER_NAME
      );
      const publishStatus = parseInt(isPublish)
        ? statuses.active
        : statuses.inActive;

      const activeStatuses = await getActiveStatuses();
      const { id: status } = activeStatuses?.find(
        (rec) => rec.name === publishStatus
      );
      const { id: activeStatusId } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const planCreated = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            const planThumbnail = await workoutPlanThumbnailsModel.create(
              {
                uuid: uuidv4(),
                name: req.files.thumbnail.name,
                filename: req.files.thumbnail.name,
                savedLocation: imageData.Key,
                statusId: activeStatusId,
              },
              { transaction: t }
            );
            const workoutPlanCreated = await workoutPlansModel.create(
              {
                uuid: uuidv4(),
                name: name,
                description: description,
                noOfWorkouts: totalWorkouts,
                thumbNailId: planThumbnail.id,
                createdBy: req.decoded.id,
                statusId: status,
              },
              { transaction: t }
            );

            const planDetails = videoIds.map((id) => {
              return {
                workoutPlanId: workoutPlanCreated.id,
                workoutVideoId: id,
                statusId: activeStatusId,
                createdBy: req.decoded.id,
              };
            });
            await workoutPlanDetailsModel.bulkCreate(planDetails, {
              transaction: t,
            });

            const programsData = programIds.map((id) => {
              return {
                workoutPlanId: workoutPlanCreated.id,
                workoutCategoryId: 1,
                workoutSubCategoryId: id,
                statusId: activeStatusId,
                createdBy: req.decoded.id,
              };
            });
            await workoutPlanCategoriesModel.bulkCreate(programsData, {
              transaction: t,
            });

            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });
      if (!planCreated)
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("WORKOUT_PLAN_ADDED"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getAllWorkoutPlans: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const validations = {
        page: "required",
        pageSize: "required",
      };

      const { data: validationData, status: validationStatus } = await validate(
        req.query,
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("required_inputs"),
          400,
          validationData
        );
      }
      const page = parseInt(req.query.page);
      const pageSize = parseInt(req.query.pageSize);
      const sortByDefault = ["createdAt", "DESC"];
      const sortBy = sortByDefault;
      const {
        search: filterString,
        status: filterStatus,
        program: filterProgram,
      } = req.query;

      let statusId;
      if (filterStatus) {
        const activeStatuses = await getActiveStatuses();
        statusId = activeStatuses?.find(
          (rec) => rec.name === statuses[filterStatus]
        ).id;
      }

      let whereClause = {};
      const searchByColumns = ["workout_plan.name"];
      if (filterString || filterStatus) {
        const filters = {
          searchByColumns,
          filterString,
          whereClause,
          statusId: statusId || "",
        };
        whereClause = addFiltersToWhereClause(filters);
      }

      const userData = await userModel.findOne({
        where: { id: req.decoded.id },
      });

      const activeStatuses = await getActiveStatuses();
      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );
      const { id: deleteStatusId } = activeStatuses?.find(
        (rec) => rec.name === statuses.deleted
      );

      const adminData = await usersTypesModel.findOne({
        where: { name: userTypes.admin },
      });

      //filter deleted plans from listing
      whereClause.statusId = { [Op.ne]: deleteStatusId };

      if (userData.userTypeId != adminData.id) {
        whereClause.statusId = { [Op.eq]: activeStatus };
      }

      //filter plans according to program
      let filterPrograms;
      if (filterProgram) {
        filterPrograms = { workoutSubCategoryId: filterProgram };
      }

      const { count, rows } = await workoutPlansModel.findAndCountAll({
        attributes: [
          "id",
          "uuid",
          "name",
          "description",
          "noOfWorkouts",
          "createdAt",
        ],
        include: [
          {
            model: workoutPlanCategoriesModel,
            attributes: ["workoutSubCategoryId"],
            where: filterPrograms,
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: workoutPlanThumbnailsModel,
            attributes: ["savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.plan },
            required: false,
          },
        ],
        where: whereClause,
        order: [sortBy],
        offset: (page - 1) * pageSize,
        limit: pageSize,
        group: ["id"],
      });

      rows.map((data) => {
        const {
          workout_plan_thumbnail: { savedLocation: thumbnailLink },
        } = data;
        const signedLink = getSignedUrlFromS3(thumbnailLink);
        data.dataValues.isLiked = data.dataValues.user_workout_plan
          ? true
          : false;
        return {
          ...data,
          ...(data.workout_plan_thumbnail.savedLocation = signedLink),
        };
      });

      if (rows) {
        return createResponse(
          res,
          successStatus,
          { records: rows, totalCount: count.length, page, pageSize },
          translateObj.__("PLANS_FETCHED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PLANS_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  editWorkoutPlan: async (req, res) => {
    try {
      const validations = {
        uuid: "required",
      };
      const translateObj = translate(req.headers.lang);
      const { data: validationData, status: validationStatus } = await validate(
        { ...req.params },
        validations
      );
      if (!validationStatus) {
        throw new handleError(
          translateObj.__("VALIDATION_ERROR"),
          400,
          validationData
        );
      }
      const {
        body: { name, description, totalWorkouts, isPublish, videos, programs },
      } = req;
      const {
        params: { uuid },
      } = req;
      let videoIds;
      let programIds;
      if (videos) videoIds = videos.split(",");
      if (programs) programIds = programs.split(",");
      let imageData;
      if (req.files && req.files.thumbnail) {
        imageData = await uploadFilesToS3(
          [req.files.thumbnail],
          process.env.AWS_S3_WORKOUT_VIDEO_THUMBNAILS_FOLDER_NAME
        );
        if (!imageData)
          throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      }
      const publishStatus = parseInt(isPublish)
        ? statuses.active
        : statuses.inActive;

      const activeStatuses = await getActiveStatuses();
      const { id: status } = activeStatuses?.find(
        (rec) => rec.name === publishStatus
      );
      const { id: activeStatusId } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );
      const workoutPlanData = await workoutPlansModel.findOne({
        where: { uuid: uuid },
      });
      if (workoutPlanData.noOfWorkouts < 1 && parseInt(isPublish) && !videos) {
        throw new handleError(
          translateObj.__("CANNOT_PUBLISH_PLAN_WITHOUT_WORKOUTS"),
          400
        );
      }
      const planCreated = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            if (req.files && req.files.thumbnail) {
              await workoutPlanThumbnailsModel.update(
                {
                  name: req.files.thumbnail.name,
                  filename: req.files.thumbnail.name,
                  savedLocation: imageData.Key,
                },
                {
                  where: {
                    id: workoutPlanData.thumbNailId,
                  },
                  transaction: t,
                }
              );
            }
            await workoutPlansModel.update(
              {
                name: name,
                description: description,
                noOfWorkouts: totalWorkouts,
                thumbNailLocation: imageData?.Key,
                updatedBy: req.decoded.id,
                statusId: status,
              },
              {
                where: {
                  uuid: uuid,
                },
                transaction: t,
              }
            );
            if (videoIds) {
              await workoutPlanDetailsModel.destroy({
                where: {
                  workoutPlanId: workoutPlanData.id,
                },
                transaction: t,
              });
              const planDetails = videoIds.map((id) => {
                return {
                  workoutPlanId: workoutPlanData.id,
                  workoutVideoId: id,
                  statusId: activeStatusId,
                  createdBy: req.decoded.id,
                };
              });
              await workoutPlanDetailsModel.bulkCreate(planDetails, {
                transaction: t,
              });
            }
            if (programIds) {
              await workoutPlanCategoriesModel.destroy({
                where: {
                  workoutPlanId: workoutPlanData.id,
                },
                transaction: t,
              });
              const programsData = programIds.map((id) => {
                return {
                  workoutPlanId: workoutPlanData.id,
                  workoutCategoryId: 1,
                  workoutSubCategoryId: id,
                  statusId: activeStatusId,
                  createdBy: req.decoded.id,
                };
              });
              await workoutPlanCategoriesModel.bulkCreate(programsData, {
                transaction: t,
              });
            }
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });
      if (!planCreated)
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      return createResponse(
        res,
        successStatus,
        {},
        translateObj.__("WORKOUT_PLAN_UPDATED"),
        200
      );
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  getWorkoutPlan: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);

      const activeStatuses = await getActiveStatuses();
      const { id: activeStatusId } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const planDataWithVideos = await workoutPlansModel.findOne({
        attributes: ["uuid", "name", "description", "noOfWorkouts"],
        where: {
          uuid: req.params.planUuid,
        },
        include: [
          {
            model: workoutPlanDetailsModel,
            attributes: ["id"],
            where: {
              statusId: {
                [Op.eq]: activeStatusId,
              },
            },
            include: [
              {
                model: workoutVideosModel,
                include: [
                  {
                    model: workoutsModel,
                    attributes: ["id", "uuid", "name", "description"],
                    include: [
                      {
                        model: workoutVideoDetailsModel,
                        attributes: ["workoutSubCategoryId"],
                        include: [
                          {
                            model: workoutCategoriesModel,
                            attributes: ["name"],
                            where: { name: "program" },
                          },
                          {
                            model: workoutSubCategoriesModel,
                            attributes: ["name"],
                          },
                        ],
                      },
                    ],
                  },
                  {
                    model: workoutInstructorsModel,
                    attributes: ["name"],
                  },
                  {
                    model: videoThumbnailsModel,
                    attributes: ["savedLocation"],
                  },
                  {
                    model: userWorkoutPlansModel,
                    attributes: ["id", "userId"],
                    where: {
                      userId: req.decoded.id,
                      type: savedWorkoutType.video,
                    },
                    required: false,
                  },
                  {
                    model: plannedWorkoutUserDetailsModel,
                    attributes: ["id", "workoutSessionDate"],
                    where: { userId: req.decoded.id },
                    required: false,
                  },
                ],
              },
            ],
          },
          {
            model: workoutPlanCategoriesModel,
            attributes: ["id"],
            include: [
              {
                model: workoutCategoriesModel,
                attributes: ["name"],
              },
              {
                model: workoutSubCategoriesModel,
                attributes: ["id", "name"],
              },
            ],
          },
          {
            model: statusModel,
            attributes: ["name"],
          },
          {
            model: workoutPlanThumbnailsModel,
            attributes: ["savedLocation"],
          },
          {
            model: userWorkoutPlansModel,
            attributes: ["id", "userId"],
            where: { userId: req.decoded.id, type: savedWorkoutType.plan },
            required: false,
          },
        ],
      });

      const flatData = (details) => {
        return {
          uuid: details.uuid,
          name: details.name,
          description: details.description,
          noOfWorkouts: details.noOfWorkouts,
          status: details.status.name,
          thumbNail: getSignedUrlFromS3(
            details.workout_plan_thumbnail.savedLocation
          ),
          isLiked: details.user_workout_plan ? true : false,
          plan_videos: details.workout_plan_details?.length
            ? flattenWorkouts(
                details.workout_plan_details.map((data) => {
                  return data.workout_video;
                }),
                false
              )
            : null,
          programs: details.workout_plan_categories.map((data) => {
            return {
              id: data.workout_sub_category.id,
              name: data.workout_sub_category.name,
            };
          }),
        };
      };

      let planData;
      if (!planDataWithVideos) {
        const planDetails = await workoutPlansModel.findOne({
          attributes: [
            "uuid",
            "name",
            "description",
            "noOfWorkouts",
            "thumbNailId",
          ],
          where: {
            uuid: req.params.planUuid,
          },
          include: [
            {
              model: statusModel,
              attributes: ["name"],
            },
            {
              model: workoutPlanThumbnailsModel,
              attributes: ["savedLocation"],
            },
            {
              model: workoutPlanCategoriesModel,
              attributes: ["id"],
              include: [
                {
                  model: workoutCategoriesModel,
                  attributes: ["name"],
                },
                {
                  model: workoutSubCategoriesModel,
                  attributes: ["id", "name"],
                },
              ],
            },
            {
              model: userWorkoutPlansModel,
              attributes: ["id", "userId"],
              where: { userId: req.decoded.id, type: savedWorkoutType.plan },
              required: false,
            },
          ],
        });
        planData = flatData(planDetails);
      } else {
        planData = flatData(planDataWithVideos);
      }

      if (planData) {
        return createResponse(
          res,
          successStatus,
          planData,
          translateObj.__("PLAN_FETCHED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PLAN_NOT_FOUND"),
          400
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  deleteWorkoutPlan: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const {
        params: { uuid },
      } = req;

      const planDeleteData = await model.sequelize
        .transaction()
        .then(async (t) => {
          try {
            const planDeleteData = await workoutPlansModel.findOne({
              where: { uuid },
            });
            await workoutPlansModel.destroy({
              where: { id: planDeleteData.id },
            });

            /*Cascade delete can not be added in this table*/
            await userWorkoutPlansModel.destroy({
              where: {
                planOrVideoId: planDeleteData.id,
                type: savedWorkoutType.plan,
              },
              transaction: t,
            });
            /*Cascade delete can not be added in this table*/
            await workoutPlanThumbnailsModel.destroy({
              where: {
                id: planDeleteData.thumbNailId,
              },
              transaction: t,
            });
            t.commit();
            return true;
          } catch (e) {
            console.log(e);
            t.rollback();
            return false;
          }
        });

      if (planDeleteData) {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PLAN_DELETED"),
          200
        );
      } else {
        return createResponse(
          res,
          successStatus,
          {},
          translateObj.__("PLAN_DELETE_ERROR"),
          402
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
  saveWorkoutPlan: async (req, res) => {
    try {
      const translateObj = translate(req.headers.lang);
      const activeStatuses = await getActiveStatuses();
      const { id: activeStatus } = activeStatuses?.find(
        (rec) => rec.name === statuses.active
      );

      const getPlanData = await workoutPlansModel.findOne({
        where: {
          [Op.and]: [{ uuid: req.body.planUuid }, { statusId: activeStatus }],
        },
      });

      if (!getPlanData)
        throw new handleError(translateObj.__("DELETED_PLAN"), 422);

      const isPlanAlreadySaved = await userWorkoutPlansModel.findOne({
        where: {
          [Op.and]: [
            { planOrVideoId: getPlanData.id },
            { userId: req.decoded.id },
            { type: savedWorkoutType.plan },
          ],
        },
      });

      const messageKey = isPlanAlreadySaved ? "PLAN_UNSAVED" : "PLAN_SAVED";
      const isSaved = isPlanAlreadySaved ? 0 : 1;

      let savedPlanData;
      if (isPlanAlreadySaved) {
        savedPlanData = await userWorkoutPlansModel.destroy({
          where: {
            [Op.and]: [
              { planOrVideoId: getPlanData.id },
              { userId: req.decoded.id },
              { type: savedWorkoutType.plan },
            ],
          },
        });
      } else {
        savedPlanData = await userWorkoutPlansModel.create({
          uuid: uuidv4(),
          userId: req.decoded.id,
          type: savedWorkoutType.plan,
          planOrVideoId: getPlanData.id,
          videoSavedDate: moment().utc().format(dateFormat1),
          statusId: activeStatus,
          createdBy: req.decoded.id,
        });
      }

      if (!savedPlanData) {
        throw new handleError(translateObj.__("UNKNOWN_ERROR"), 500);
      } else {
        return createResponse(
          res,
          successStatus,
          { isLiked: isSaved },
          translateObj.__(messageKey),
          200
        );
      }
    } catch (e) {
      console.error(e);
      return createResponse(
        res,
        errorStatus,
        {},
        e.message,
        e.code,
        e.errorData
      );
    }
  },
};
