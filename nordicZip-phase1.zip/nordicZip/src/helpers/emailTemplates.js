const otpTemplate = `<p>Hi User,<br />&nbsp;<br />Your OTP is :&nbsp;@otp@<br />please note this otp is valid for ${process.env.OTP_EXPIRES_IN} min and can be used only once. For optimum security, please don&#39;t share your OTP with anyone.</p><p>Thank you.</p>`;

const otpEmailTemplate = (email, otpString) => {
  return otpTemplate.replace("@otp@", otpString);
};
module.exports = {
  otpEmailTemplate,
};
