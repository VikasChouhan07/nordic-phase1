const dateFormat1 = "YYYY-MM-DD HH:mm:ss";
const dateFormat2 = "YYYY-MM-DD 00:00:00";
const dateFormat3 = "YYYY-MM-DD";
module.exports = { dateFormat1, dateFormat2, dateFormat3 };
