const axios = require("axios");
const qs = require("qs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const moment = require("moment");
const googleLogin = async (token) => {
  try {
    const config = {
      method: "get",
      url: `https://oauth2.googleapis.com/tokeninfo?id_token=${token}`,
    };
    const userData = await axios(config);
    return userData.data.email;
  } catch (e) {
    console.log(e);
    return false;
  }
};

const facebookLogin = async (token, email) => {
  try {
    const config = {
      method: "get",
      url: `https://graph.facebook.com/oauth/access_token?client_id=${process.env.FACEBOOK_LOGIN_CLIENT_ID}&client_secret=${process.env.FACEBOOK_LOGIN_CLIENT_SECRET}&grant_type=client_credentials`,
    };
    const accessData = await axios(config);
    console.log(`accessDataToken`, accessData.data.access_token);
    const configTwo = {
      method: "get",
      url: `https://graph.facebook.com/debug_token?input_token=${token}&access_token=${accessData.data.access_token}`,
    };

    const fbUserData = await axios(configTwo);
    if (fbUserData.data.data.is_valid && email) {
      const configThree = {
        method: "get",
        url: `https://graph.facebook.com/me?fields=id,email&access_token=${token}`,
      };
      const checkEmail = await axios(configThree);
      if (checkEmail.data.email !== email) return false;
    }
    return fbUserData.data.data.is_valid;
  } catch (e) {
    console.log(e);
    return false;
  }
};

const appleLogin = async (token, email) => {
  try {
    const key = fs.readFileSync(
      __dirname + "/../../apple/AuthKey_B93D675W65.p8",
      "utf8"
    );
    const jwtToken = jwt.sign(
      {
        iss: process.env.APPLE_LOGIN_CLIENT_SECRET,
        iat: moment().utc().unix(),
        exp: moment().utc().unix() + 60 * 3600,
        aud: "https://appleid.apple.com",
        sub: process.env.APPLE_LOGIN_CLIENT_ID,
      },
      key,
      {
        algorithm: "ES256",
        header: { alg: "ES256", kid: process.env.APPLE_LOGIN_KID },
      }
    );

    const data = qs.stringify({
      client_id: process.env.APPLE_LOGIN_CLIENT_ID,
      client_secret: jwtToken,
      code: token,
      grant_type: "authorization_code",
    });
    let config = {
      method: "post",
      url: "https://appleid.apple.com/auth/token",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      data: data,
    };
    const appleUserData = await axios(config);
    if (email) {
      const userData = await jwt.decode(appleUserData.data.id_token);
      return email === userData.email;
    }
    return true;
  } catch (e) {
    console.log(e);
    return false;
  }
};

module.exports = {
  googleLogin,
  facebookLogin,
  appleLogin,
};
