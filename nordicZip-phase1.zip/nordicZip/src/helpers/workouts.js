const { getSignedUrlFromS3 } = require("./aws");

const flattenWorkouts = (data, getSubcategoryId) => {
  return data.map((data) => {
    return {
      id: data.id,
      uuid: data.uuid,
      savedLocation: getSignedUrlFromS3(data.savedLocation),
      size: data.size,
      duration: data.duration,
      createdAt: data.createdAt,
      workout_id: data.workout.id,
      workout_uuid: data.workout.uuid,
      workout_name: data.workout.name,
      workout_description: data.workout.description,
      workout_programs: data.workout.workout_video_details
        .map((obj) => {
          if (obj.workout_category.name === "program")
            return getSubcategoryId
              ? obj.workout_sub_category.id
              : obj.workout_sub_category.name;
        })
        .filter((o) => o),
      workout_focuses: data.workout.workout_video_details
        .map((obj) => {
          if (obj.workout_category.name === "focus")
            return getSubcategoryId
              ? obj.workout_sub_category.id
              : obj.workout_sub_category.name;
        })
        .filter((o) => o),
      workout_muscle_groups: data.workout.workout_video_details
        .map((obj) => {
          if (obj.workout_category.name === "muscles group")
            return getSubcategoryId
              ? obj.workout_sub_category.id
              : obj.workout_sub_category.name;
        })
        .filter((o) => o),
      workout_goals: data.workout.workout_video_details
        .map((obj) => {
          if (obj.workout_category.name === "goals")
            return getSubcategoryId
              ? obj.workout_sub_category.id
              : obj.workout_sub_category.name;
        })
        .filter((o) => o),
      workout_instructor: data.workout_instructor.name,
      video_thumbnail: getSignedUrlFromS3(data.video_thumbnail.savedLocation),
      isDeleted: data.isDeleted,
      isFeatured: data.isFeatured,
      status: data.status ? data.status.name : null,
      isLiked:
        data.user_workout_plan || data.user_workout_plans.length ? true : false,
      scheduledDate: data.planned_workout_user_detail
        ? data.planned_workout_user_detail.workoutSessionDate
        : null,
      ...(data.completed_workouts && {
        isCompleted: data.completed_workouts.length ? true : false,
      }),
    };
  });
};

const flatRecommendationData = (data) => {
  return data.map((data) => {
    return {
      id: data.id,
      uuid: data.uuid,
      workoutVideoId: data.workoutVideoId,
      fromPublishDate: data.fromPublishDate,
      toPublishDate: data.toPublishDate,
      workout_name: data.workout_video.workout.name,
      instructor_name: data.workout_video.workout_instructor.name,
      status: data.status.name,
      workout_goals: data.recommendation_workout_details[0],
    };
  });
};

const flattenSavedWorkouts = (data) => {
  return data.map((data) => {
    return {
      id: data.id,
      uuid: data.uuid,
      workout_name: data.workout.name,
      duration: data.duration,
      workout_programs: data.workout.workout_video_details
        .map((obj) => {
          return obj.workout_sub_category.name;
        })
        .filter((o) => o),
      workout_instructor: data.workout_instructor.name,
      video_thumbnail: getSignedUrlFromS3(data.video_thumbnail.savedLocation),
      isLiked:
        data.user_workout_plan || data.user_workout_plans.length ? true : false,
      ...(data.planned_workout_user_detail && {
        scheduledDate: data.planned_workout_user_detail.workoutSessionDate,
      }),
    };
  });
};

module.exports = {
  flattenWorkouts,
  flatRecommendationData,
  flattenSavedWorkouts,
};
