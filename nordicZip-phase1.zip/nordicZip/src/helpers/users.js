const { getActiveStatuses, statuses } = require("./sequelize");
const model = require("../models/index");
const usersOnboardingDetailsModel = model.user_onboarding_detail;
const moment = require("moment");
const { dateFormat1 } = require("./dates");

const addOnboardingData = async (onboardingData, userData) => {
  try {
    const {
      measurementSystem,
      height,
      weight,
      trainingGoal,
      workoutFrequency,
      workoutDuration,
      workoutFrequencyType,
    } = onboardingData;
    const activeStatuses = await getActiveStatuses();
    const activeStatus = activeStatuses?.find(
      (rec) => rec.name === statuses.active
    ).id;
    const onboardingDataCreate = await usersOnboardingDetailsModel.create({
      userId: userData.id,
      measurementId: measurementSystem,
      goalCategoryId: trainingGoal,
      workoutDurationId: workoutDuration,
      workoutFrequencyId: workoutFrequencyType,
      workoutFrequency: parseInt(workoutFrequency),
      onboardingDate: moment().utc().format(dateFormat1),
      isPlanned: 0,
      height: height,
      weight: weight,
      statusId: activeStatus,
    });
    if (!onboardingDataCreate) return false;
    return true;
  } catch (e) {
    console.log(e);
    return false;
  }
};

const userType = {
  user: 1,
  admin: 2,
};

const userTypes = {
  user: "User",
  admin: "Admin",
};

const savedWorkoutType = {
  plan: 2,
  video: 1,
};

const logins = {
  default: "default",
  admin: "admin",
  facebook: "facebook",
  google: "google",
  apple: "apple",
};

const trophiesParameters = {
  noOfTrophies: 5,
  twoWorkoutsCompleted: 2,
  eightWorkoutsCompleted: 8,
  twelveWorkoutsCompleted: 12,
  fourWokoutsInOneWeek: 4,
  bestTime1000meters: 1000
}

const updateNumbers = {
  incrementDecrement: 1
}

const flattenUsers = (data) => {
  return data.map((data) => {
    if (!data.user_onboarding_detail) {
      return {
        firstName: data.firstName,
        uuid: data.uuid,
        email: data.email,
        imageLocation: data.imageLocation,
        gender: data.gender,
        registrationDate: data.registrationDate,
        statusId: data.statusId,
        isOnboarded: false,
      };
    }
    return {
      firstName: data.firstName,
      uuid: data.uuid,
      email: data.email,
      imageLocation: data.imageLocation,
      gender: data.gender,
      registrationDate: data.registrationDate,
      statusId: data.statusId,
      height: `${data.user_onboarding_detail.height} ${data.user_onboarding_detail.measurement_system.measurement_system_units[1].unit.shortName}`,
      weight: `${data.user_onboarding_detail.weight} ${data.user_onboarding_detail.measurement_system.measurement_system_units[0].unit.shortName}`,
      workoutFrequency: data.user_onboarding_detail.workoutFrequency,
      measurement_system: data.user_onboarding_detail.measurement_system.name,
      workout_goal: data.user_onboarding_detail.workout_sub_category.name,
      workout_frequency_type:
        data.user_onboarding_detail.workout_frequency_type.name,
      workout_duration_type:
        data.user_onboarding_detail.workout_duration_type.name,
      isOnboarded: true,
    };
  });
};

const findCompletedWorkoutsPerWeek = (
  startDate,
  endDate,
  completedWorkoutsDates
) => {
  const noOfDays = moment(endDate).diff(moment(startDate), "days");
  let totalWeeks = parseInt(noOfDays / 7);
  totalWeeks+=2;
  
  let weeksFromOnboardingDate = [];
  for (let i = 0; i < totalWeeks; i++) {
    weeksFromOnboardingDate[i] = {
      startDate: moment()
        .subtract(i, "weeks")
        .startOf("isoWeek")
        .format("YYYY-MM-DD"),
      endDate: moment()
        .subtract(i, "weeks")
        .endOf("isoWeek")
        .format("YYYY-MM-DD"),
    };
  }

  let weeksArr = [];
  weeksFromOnboardingDate.forEach((week, i) => {
    completedWorkoutsDates.forEach((date) => {
      if (moment(date.completionDate).isBetween(week.startDate, week.endDate)) {
        weeksArr[i] = weeksArr[i] ? weeksArr[i] + 1 : 1;
      } else {
        weeksArr[i] = weeksArr[i] ? weeksArr[i] : 0;
      }
    });
  });

  return weeksArr;
};

module.exports = {
  addOnboardingData,
  userType,
  logins,
  flattenUsers,
  userTypes,
  savedWorkoutType,
  findCompletedWorkoutsPerWeek,
  updateNumbers,
  trophiesParameters
};
