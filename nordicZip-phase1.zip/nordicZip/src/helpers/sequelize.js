const Sequelize = require("sequelize");
const model = require("../models/index");
const statusModel = model.status;
const Op = Sequelize.Op;
const queryType = model.query_type;
const moment = require("moment");
const createSortBy = (sortValues) => {
  const sortBy = [];
  let srtArr = [];
  sortValues.forEach((d) => {
    d = JSON.parse(d);
    if (d.desc === true) {
      srtArr = [d.id, "DESC"];
    } else {
      srtArr = [d.id, "ASC"];
    }
    if (d.model) {
      srtArr.unshift(d.model);
    }
    if (d.superModel) {
      srtArr.unshift(d.superModel);
    }
  });
  return [...sortBy, ...srtArr];
};

const addFiltersToWhereClause = (filters) => {
  console.log(filters);
  let searchClause = {};
  if (filters.filterString) {
    searchClause = {
      [Op.or]:
        filters.filterString &&
        filters?.searchByColumns.map((name) => ({
          [`$${name}$`]: { [Op.like]: "%" + filters.filterString + "%" },
        })),
    };
  }

  let filterDateClause = {};
  if ((filters.fromDate || filters.toDate) && filters.dateFilterColumn) {
    filterDateClause = addDateFiltersToWhereClause(
      filters.dateFilterColumn,
      filters.fromDate,
      filters.toDate
    );
  }

  let statusClause = {};
  if (filters.statusId) {
    statusClause = { statusId: parseInt(filters.statusId) };
  }

  return {
    [Op.and]: [searchClause, statusClause, filterDateClause],
  };
};

const addDateFiltersToWhereClause = (columns, startDate, endDate) => {
  let filterClause = {};
  if (!startDate) {
    filterClause[columns] = {
      [Op.lte]: moment(endDate).set({ hour: 23, minute: 59 }),
    };
  } else if (!endDate) {
    filterClause[columns] = { [Op.gte]: moment(startDate) };
  } else {
    filterClause[columns] = {
      [Op.and]: [
        { [Op.gte]: moment(startDate) },
        { [Op.lte]: moment(endDate).set({ hour: 23, minute: 59 }) },
      ],
    };
  }
  return filterClause;
};

const getActiveStatuses = async () => {
  const statuses = await statusModel.findAll({
    attributes: ["id", "name"],
  });
  return statuses?.map((s) => s.dataValues);
};

const getQueriesType = async () => {
  const queriesData = await queryType.findAll({
    attributes: ["id", "name"],
  });
  return queriesData?.map((s) => s.dataValues);
};

const statuses = {
  active: "active",
  inActive: "inActive",
  deleted: "deleted",
};

const queryFilters = {
  resolved: "1",
  unresolved: "0",
};

const userQueryTypes = {
  report: "Report an Issue",
  faq: "FAQ",
  privacyPolicy: "Privacy policy",
};

const categoryIds = {
  Programs: 1,
  muscleGroup: 2,
  Focus: 3,
  Goals: 4,
};
module.exports = {
  createSortBy,
  addFiltersToWhereClause,
  getActiveStatuses,
  statuses,
  getQueriesType,
  userQueryTypes,
  queryFilters,
  categoryIds,
};
