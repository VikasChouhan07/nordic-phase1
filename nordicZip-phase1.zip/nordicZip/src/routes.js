const router = require("express").Router();
const { checkToken, checkAdminCredentials } = require("./middleware");
const moment = require("moment");
const usersControllerV1 = require("./controllers/v1/usersController");
const adminControllerV1 = require("./controllers/v1/adminController");
const authControllerV1 = require("./controllers/v1/authController");
const workoutsControllerV1 = require("./controllers/v1/workoutsController");
const reportsAndFaqController = require("./controllers/v1/reportsAndFaqController");
const recommendationControllerV1 = require("./controllers/v1/recommendationsController");
const workoutPlansControllerV1 = require("./controllers/v1/workoutPlansController");
/*---------------------------------------------------------------------------------
 Define All the Routes Below. The routes will follow REST API standards strictly.
 ---------------------------------------------------------------------------------*/
router.get("/", (req, res) => {
  const port = process.env.PORT || 3001;
  res.send(
    `Nordic Strong Express Application is running on this Server. Server Datetime: ${moment().format(
      "MMMM Do YYYY, h:mm:ss a z"
    )} <br><br> Swagger is running on <a href="http://localhost:${port}/api-docs">http://localhost:${port}/api-docs</a>`
  );
});

// Authentication Routes
router.post("/v1/login", authControllerV1.login);
router.post("/v1/logout", checkToken, authControllerV1.logout);
router.post("/v1/refresh-token", authControllerV1.getToken);
router.get("/v1/otp/:email", authControllerV1.getOtp);
router.get("/v1/otp-admin/:email", authControllerV1.getOtpForAdmin);
router.post("/v1/signup", authControllerV1.signup);

router.post(
  "/v1/onboarding-details",
  checkToken,
  authControllerV1.addOnboardingDetails
);

router.post("/v1/users", checkToken, usersControllerV1.addUser);
router.get("/v1/users/:uuid", checkToken, usersControllerV1.getUser);
router.get("/v1/programs", usersControllerV1.getPrograms);
router.get("/v1/muscle-groups", usersControllerV1.getMuscleGroups);
router.get("/v1/training-goals", usersControllerV1.getTrainingGoals);
router.get("/v1/focuses", usersControllerV1.getFocuses);
router.get("/v1/measurement-systems", usersControllerV1.getMeasurementSystems);
router.get(
  "/v1/workout-duration-types",
  usersControllerV1.getWorkoutDurationTypes
);
router.get(
  "/v1/workout-frequency-types",
  usersControllerV1.getWorkoutFrequencyTypes
);

router.put("/v1/users/:uuid/reset-password", authControllerV1.changePassword);
router.post(
  "/v1/users/:uuid/change-password",
  checkToken,
  authControllerV1.changePassword
);
router.post("/v1/verify-otp", authControllerV1.verifyOtp);
router.post("/v1/otp-verify", authControllerV1.appOtpVerify);

// Admin Controller Routes
router.get(
  "/v1/otp/:email/type/new-email",
  checkToken,
  authControllerV1.getNewEmailOtp
);
router.get(
  "/v1/admins/:uuid",
  checkToken,
  checkAdminCredentials,
  adminControllerV1.getAdmin
);

router.get("/v1/users", checkToken, adminControllerV1.getUsers);
router.put(
  "/v1/admins/:uuid",
  checkToken,
  checkAdminCredentials,
  adminControllerV1.update
);
router.put("/v1/users/:uuid", checkToken, usersControllerV1.update);
router.patch(
  "/v1/users/:uuid/status/:status",
  checkToken,
  checkAdminCredentials,
  adminControllerV1.updateStatus
);
router.patch(
  "/v1/users/:uuid/email",
  checkToken,
  checkAdminCredentials,
  adminControllerV1.updateEmail
);
router.post(
  "/v1/workout-videos",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV1.addWorkoutVideo
);

router.get(
  "/v1/workout-videos",
  checkToken,
  workoutsControllerV1.getWorkoutVideos
);
router.get(
  "/v1/workout-videos/category/:type/sub-category-id/:id",
  checkToken,
  workoutsControllerV1.getWorkoutVideosCategory
);
router.get(
  "/v1/workout-videos/:uuid",
  checkToken,
  workoutsControllerV1.getWorkout
);
router.put(
  "/v1/workout-videos/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV1.updateWorkoutVideo
);
router.get(
  "/v1/workout-videos/user/:userUuid",
  checkToken,
  workoutsControllerV1.getSavedWorkout
);
router.get(
  "/v1/workout-videos/similar-workouts/:videoUuid",
  checkToken,
  workoutsControllerV1.getSimilarWorkouts
);

router.post(
  "/v1/planned-workouts",
  checkToken,
  workoutsControllerV1.scheduleWorkout
);
router.delete(
  "/v1/workout-videos",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV1.deleteWorkouts
);
router.patch(
  "/v1/workout-videos/featured/:featured",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV1.featureWorkouts
);
router.patch(
  "/v1/workout-videos/:uuid/status/:status",
  checkToken,
  checkAdminCredentials,
  workoutsControllerV1.updateWorkoutStatus
);
router.post(
  "/v1/workout-videos/user/:uuid",
  checkToken,
  workoutsControllerV1.saveWorkoutForUser
);

router.get(
  "/v1/completed-workouts",
  checkToken,
  workoutsControllerV1.getWorkoutsHistory
);

router.post(
  "/v1/completed-workouts",
  checkToken,
  workoutsControllerV1.markWorkoutCompleted
);

router.get("/v1/instructors", adminControllerV1.getInstructors);
router.get(
  "/v1/recommendation/:uuid",
  checkToken,
  recommendationControllerV1.getRecommendationOfAdmin
);

// Recommendation Controller Routes
router.post(
  "/v1/recommendations",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV1.addRecommendation
);
router.put(
  "/v1/recommendations/:id",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV1.editRecommendation
);
router.get(
  "/v1/recommendations",
  checkToken,
  recommendationControllerV1.getRecommendation
);
router.delete(
  "/v1/recommendation/:uuid",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV1.deleteRecommendation
);

router.patch(
  "/v1/recommendations/:uuid/publish/:publish",
  checkToken,
  checkAdminCredentials,
  recommendationControllerV1.publishRecommendation
);

router.get(
  "/v1/recommendations/user/:userUuid",
  checkToken,
  recommendationControllerV1.getTodaysRecommendation
);

// Report and FAQ Controller Routes
router.get("/v1/faqs", checkToken, reportsAndFaqController.getFaqs);
router.get("/v1/faqs/:id", checkToken, reportsAndFaqController.getFaq);
router.delete(
  "/v1/faqs/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.deleteFaq
);
router.put(
  "/v1/faqs/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.editFaq
);
router.post(
  "/v1/faqs",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.postFaq
);
router.post("/v1/queries", checkToken, reportsAndFaqController.postIssue);
router.get(
  "/v1/queries/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.getQuery
);
router.delete(
  "/v1/queries/:id",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.deleteIssue
);
router.patch(
  "/v1/queries/:id/resolved/:resolved",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.resolveIssue
);
router.get(
  "/v1/queries",
  checkToken,
  checkAdminCredentials,
  reportsAndFaqController.getAllQueries
);

//Workout Plans Controller Routes
router.post(
  "/v1/workout-plans",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV1.addWorkoutPlan
);

router.get(
  "/v1/workout-plans",
  checkToken,
  workoutPlansControllerV1.getAllWorkoutPlans
);

router.delete(
  "/v1/workout-plans/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV1.deleteWorkoutPlan
);

router.put(
  "/v1/workout-plans/:uuid",
  checkToken,
  checkAdminCredentials,
  workoutPlansControllerV1.editWorkoutPlan
);

router.get(
  "/v1/workout-plans/plan/:planUuid",
  checkToken,
  workoutPlansControllerV1.getWorkoutPlan
);

router.post(
  "/v1/saved-workout-plans",
  checkToken,
  workoutPlansControllerV1.saveWorkoutPlan
);

router.get(
  "/v1/planned-workouts/user/:userUuid",
  checkToken,
  workoutsControllerV1.getScheduledWorkouts
);

router.get("/v1/trophies/:uuid", checkToken, workoutsControllerV1.getTrophies);

router.post(
  "/v1/user/workout-best-time",
  checkToken,
  workoutsControllerV1.saveUsersBestTime
);

router.get("/v1/privacy-policy", reportsAndFaqController.getPrivacyPolicy);

module.exports = router;
